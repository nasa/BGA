/*
                   Compressible Mass Flow Calculator

     Program to calculate the mass flow rate given the Mach, area
                      pressure and temperature 

                     Version 1.2a   - 21 Aug 09

                         Written by Tom Benson
                       NASA Glenn Research Center

>                              NOTICE
>This software is in the Public Domain.  It may be freely copied and used in
>non-commercial products, assuming proper credit to the author is given.  IT
>MAY NOT BE RESOLD.  If you want to use the software for commercial
>products, contact the author.
>No copyright is claimed in the United States under Title 17, U. S. Code.
>This software is provided "as is" without any warranty of any kind, either
>express, implied, or statutory, including, but not limited to, any warranty
>that the software will conform to specifications, any implied warranties of
>merchantability, fitness for a particular purpose, and freedom from
>infringement, and any warranty that the documentation will conform to the
>program, or any warranty that the software will be error free.
>In no event shall NASA be liable for any damages, including, but not
>limited to direct, indirect, special or consequential damages, arising out
>of, resulting from, or in any way connected with this software, whether or
>not based on warranty, contract, tort or otherwise, whether or not injury
>was sustained by persons or property or otherwise, and whether or not loss
>was sustained from, or arose out of the results of, or use of, the software
>or services provided hereunder.


      New Test :  Derive from Isentropic program 
                  Switch Two panels -- input (Up) - output (Dn)
                  add weight flow and w corrected / area
      Old Test


                                                     TJB 21 aug 09
*/


import java.awt.*;
import java.lang.Math ;

public class CMFlow extends java.applet.Applet {

   final double convdr = 3.14515926/180.;
   
   static double gama, gmin, gmax, gm1, gp1 ;
   static double mach, mmin, mmax ;
   static double area, amin, amax ;
   static double pres, pmin, pmax ;
   static double temp, tmin, tmax ;
   static double rgas, mflow, wflow, gc ;
   static double aconv,pconv,tconv,mconv,wconv ;
   static int units ;

   In in ;

   public void init() {

     setLayout(new GridLayout(1,2,0,0)) ;

     setDefaults () ;

     in = new In(this) ;

     add(in) ;

     comPute() ;
  }

  public Insets insets() {
     return new Insets(10,10,10,10) ;
  }

  public void setDefaults() {

       units = 0 ;
       gama = 1.4 ;
       mach = 2.0 ;
       pres = 2116. ;
       temp = 518. ;
       area = 1.0 ; 
       rgas = 1716. ;
       gc = 32.2 ;
 
       aconv = 1.0 ; pconv = 1.0 ;
       tconv = 1.0 ; mconv = 1.0 ;
       wconv = 1.0 ;

       gmin = 1.0 ;  gmax = 2.0 ;
       mmin = 0.0 ;  mmax = 25.0 ;
       pmin = 0.0 ;  pmax = 400000.0 ;
       tmin = 300.;  tmax = 8000. ;
       amin = .001 ;  amax = 5.0  ;
  }

  public void comPute() {
    double fac1, fac2 ;

    gm1 = gama -1.0 ;
    gp1 = gama +1.0 ;

    fac1 = 1.0 + .5 * gm1 * mach * mach ;
    fac2 = gp1 / (2.0 * gm1) ;
    mflow = area * pres * Math.sqrt(gama/(rgas * temp)) * 
                mach * Math.pow(fac1,-fac2) ;
    wflow = mflow * gc ;

    loadOut() ;
              
    return ; 
  }   
 
   public void loadOut() {
      String outmfl, outwfl ;

      outmfl = " slug / s" ;
      if (units == 1) outmfl = " kg / s" ;
      outwfl = " lb / s" ;
      if (units == 1) outwfl = " NT / s" ;

      in.up.f1.setText(String.valueOf(filter3(mflow * mconv)) + outmfl) ;
      in.up.f2.setText(String.valueOf(filter3(wflow * wconv)) + outwfl) ;

   }

   public float filter3(double inumbr) {
     //  output only to .001
       float number ;
       int intermed ;

       intermed = (int) (inumbr * 1000.) ;
       number = (float) (intermed / 1000. );
       return number ;
   }

   public float filter5(double inumbr) {
     //  output only to .00001
       float number ;
       int intermed ;

       intermed = (int) (inumbr * 100000.) ;
       number = (float) (intermed / 100000. );
       return number ;
   }

   class In extends Panel {
        CMFlow outerparent ;
        Up up ;
        Dn dn ;

        In (CMFlow target) {

           outerparent = target ;
           setLayout(new GridLayout(2,1,5,5)) ;

           up = new Up(outerparent) ;
           dn = new Dn(outerparent) ;

           add(dn) ;
           add(up) ;
        }

        class Up extends Panel {
             CMFlow outerparent ;
             Label l1 ;
             TextField f1,f2;

             Up (CMFlow target) {

                outerparent = target ;
                setLayout(new GridLayout(4,4,5,5)) ;

                l1 = new Label("Output", Label.LEFT) ;
                l1.setForeground(Color.blue) ;

                f1 = new TextField(String.valueOf(mflow),5) ;
                f1.setBackground(Color.black) ;
                f1.setForeground(Color.yellow) ;

                f2 = new TextField(String.valueOf(wflow),5) ;
                f2.setBackground(Color.black) ;
                f2.setForeground(Color.yellow) ;

                add(l1) ;
                add(new Label(" ", Label.RIGHT)) ;
                add(new Label(" ", Label.RIGHT)) ;
                add(new Label(" ", Label.RIGHT)) ;

                add(new Label("Mass Flow Rate", Label.RIGHT)) ;
                add(f1) ;
                add(new Label(" ", Label.RIGHT)) ;
                add(new Label(" ", Label.RIGHT)) ;

                add(new Label("Weight Flow Rate", Label.RIGHT)) ;
                add(f2) ;
                add(new Label(" ", Label.RIGHT)) ;
                add(new Label(" ", Label.RIGHT)) ;

                add(new Label(" ", Label.RIGHT)) ;
                add(new Label(" ", Label.RIGHT)) ;
                add(new Label(" ", Label.RIGHT)) ;
                add(new Label(" ", Label.RIGHT)) ;
             }
 
        } // end Up

        class Dn extends Panel {
             CMFlow outerparent ;
             Label l1,l2 ;
             Button bt1;
             Choice untch ;
             TextField o1,o2,o3,o4,o5 ;
             Label lo1,lo2,lo3,lo4,lo5 ;
             Label lu2,lu3,lu5 ;

             Dn (CMFlow target) {

                outerparent = target ;
                setLayout(new GridLayout(5,5,10,10)) ;

                l1 = new Label("Input", Label.LEFT) ;
                l1.setForeground(Color.red) ;

                l2 = new Label("Units: ", Label.RIGHT) ;
                l2.setForeground(Color.red) ;

                untch = new Choice() ;
                untch.addItem("Imperial") ;
                untch.addItem("Metric");
                untch.setBackground(Color.white) ;
                untch.setForeground(Color.red) ;
                untch.select(0) ;

                bt1 = new Button("COMPUTE") ;
                bt1.setBackground(Color.red) ;
                bt1.setForeground(Color.white) ;

                lo1 = new Label("Mach", Label.RIGHT) ;
                o1 = new TextField(String.valueOf(mach),5) ;
                o1.setBackground(Color.white) ;
                o1.setForeground(Color.black) ;

                lo2 = new Label("p total", Label.RIGHT) ;
                o2 = new TextField(String.valueOf(pres),5) ;
                o2.setBackground(Color.white) ;
                o2.setForeground(Color.black) ;
                lu2 = new Label("psf", Label.LEFT) ;

                lo3 = new Label("T total", Label.RIGHT) ;
                o3 = new TextField(String.valueOf(temp),5) ;
                o3.setBackground(Color.white) ;
                o3.setForeground(Color.black) ;
                lu3 = new Label("R", Label.LEFT) ;

                lo4 = new Label("gamma", Label.RIGHT) ;
                o4 = new TextField(String.valueOf(gama),5) ;
                o4.setBackground(Color.white) ;
                o4.setForeground(Color.black) ;

                lo5 = new Label("Area", Label.RIGHT) ;
                o5 = new TextField(String.valueOf(area),5) ;
                o5.setBackground(Color.white) ;
                o5.setForeground(Color.black) ;
                lu5 = new Label("sq ft", Label.LEFT) ;

                add(l1) ;
                add(new Label("Mass Flow", Label.RIGHT)) ;
                add(new Label("Calculator", Label.LEFT)) ;
                add(new Label(" ", Label.LEFT)) ;
                add(new Label(" ", Label.LEFT)) ;

                add(l2) ;
                add(untch) ;
                add(lo2) ;
                add(o2) ;
                add(lu2) ;

                add(lo1) ;
                add(o1) ;
                add(lo3) ;
                add(o3) ;
                add(lu3) ;

                add(lo4) ;
                add(o4) ;
                add(lo5) ;
                add(o5) ;
                add(lu5) ;

                add(new Label(" ", Label.LEFT)) ;
                add(new Label(" ", Label.LEFT)) ;
                add(bt1) ;
                add(new Label(" ", Label.LEFT)) ;
                add(new Label(" ", Label.LEFT)) ;

             }

             public boolean action(Event evt, Object arg) {
               int oldout ;
               String label = (String)arg ;

               if(evt.target instanceof Button) {
                  this.handleBut(arg) ;
                  return true ;
               }
               if(evt.target instanceof Choice) {
                  this.handleCho(arg) ;
                  return true ;
               }
               else return false ;
             } // Handler

             public void handleBut(Object arg) {
                Double V1, V2, V3, V4, V5 ;
                double v1, v2, v3, v4, v5 ;
                float fl1 ;

                 V1 = Double.valueOf(o1.getText()) ;
                 v1 = V1.doubleValue() ;
                 if(v1 < mmin) {
                   v1 = mmin ;
                   fl1 = (float) v1 ;
                   o1.setText(String.valueOf(fl1)) ;
                 }
                 if(v1 > mmax) {
                   v1 = mmax ;
                   fl1 = (float) v1 ;
                   o1.setText(String.valueOf(fl1)) ;
                 }
                 mach = v1 ;

                 V2 = Double.valueOf(o2.getText()) ;
                 v2 = V2.doubleValue() ;
                 if(v2 < pmin*pconv) {
                   v2 = pmin*pconv ;
                   fl1 = (float) v2 ;
                   o2.setText(String.valueOf(fl1)) ;
                 }
                 if(v2 > pmax*pconv) {
                   v2 = pmax*pconv ;
                   fl1 = (float) v2 ;
                   o2.setText(String.valueOf(fl1)) ;
                 }
                 pres = v2/pconv ;

                 V3 = Double.valueOf(o3.getText()) ;
                 v3 = V3.doubleValue() ;
                 if(v3 < tmin*tconv) {
                   v3 = tmin*tconv ;
                   fl1 = (float) v3 ;
                   o3.setText(String.valueOf(fl1)) ;
                 }
                 if(v3 > tmax*tconv) {
                   v3 = tmax*tconv ;
                   fl1 = (float) v3 ;
                   o3.setText(String.valueOf(fl1)) ;
                 }
                 temp = v3/tconv ;

                 V4 = Double.valueOf(o4.getText()) ;
                 v4 = V4.doubleValue() ;
                 if(v4 < gmin) {
                   v4 = gmin ;
                   fl1 = (float) v4 ;
                   o4.setText(String.valueOf(fl1)) ;
                 }
                 if(v4 > gmax) {
                   v4 = gmax ;
                   fl1 = (float) v4 ;
                   o4.setText(String.valueOf(fl1)) ;
                 }
                 gama = v4 ;

                 V5 = Double.valueOf(o5.getText()) ;
                 v5 = V5.doubleValue() ;
                 if(v5 < amin*aconv) {
                   v5 = amin*aconv ;
                   fl1 = (float) v5 ;
                   o5.setText(String.valueOf(fl1)) ;
                 }
                 if(v5 > amax*aconv) {
                   v5 = amax*aconv ;
                   fl1 = (float) v5 ;
                   o5.setText(String.valueOf(fl1)) ;
                 }
                 area = v5/aconv ;

                 comPute () ;
             }

             public void handleCho(Object arg) {
 
                 units = untch.getSelectedIndex() ;

                 if (units == 0) {      // Imperial Units
                    aconv = 1.0 ;
                    pconv = 1.0 ;
                    tconv = 1.0 ;
                    mconv = 1.0 ;
                    wconv = 1.0 ;

                    lu2.setText("psf") ;
                    lu3.setText("R") ;
                    lu5.setText("sq ft") ;
                 }

                 if (units == 1) {      // Metric Units
                    aconv = .092903 ;
                    pconv = .047873346 ;
                    tconv = .5555555 ;
                    mconv = 14.60592 ;
                    wconv = 4.448 ;

                    lu2.setText("kPa") ;
                    lu3.setText("K") ;
                    lu5.setText("sq m") ;
                 }

                 o2.setText(String.valueOf(filter3(pres*pconv))) ;
                 o3.setText(String.valueOf(filter3(temp*tconv))) ;
                 o5.setText(String.valueOf(filter3(area*aconv))) ;

                 comPute () ;
             }
        } // end Dn
   } // end In
}

