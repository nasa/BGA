/*
                             DropSim

                           A Java Applet
                      to study falling objects
                 Derived from RocketModeler III Version 1.2g

                             Version 1.0e
                               28 Jul 11

                             Written by

                             Tom Benson
                       NASA Glenn Research Center

                               and
                           
                             Anthony Vila
                         Vanderbilt University

>                              NOTICE
>This software is in the Public Domain.  It may be freely copied and used in
>non-commercial products, assuming proper credit to the author is given.  IT
>MAY NOT BE RESOLD.  If you want to use the software for commercial
>products, contact the author.
>No copyright is claimed in the United States under Title 17, U. S. Code.
>This software is provided "as is" without any warranty of any kind, either
>express, implied, or statutory, including, but not limited to, any warranty
>that the software will conform to specifications, any implied warranties of
>merchantability, fitness for a particular purpose, and freedom from
>infringement, and any warranty that the documentation will conform to the
>program, or any warranty that the software will be error free.
>In no event shall NASA be liable for any damages, including, but not
>limited to direct, indirect, special or consequential damages, arising out
>of, resulting from, or in any way connected with this software, whether or
>not based on warranty, contract, tort or otherwise, whether or not injury
>was sustained by persons or property or otherwise, and whether or not loss
>was sustained from, or arose out of the results of, or use of, the software
>or services provided hereunder.
 
  New test -
              *  Build basic code                      
              *  Get rid of unused stuff
              *  get rid of Con and Inp .. just use ballistic and launch
              *  make air density a variable 
              *     allow for neglecting this effect
              *  adjust limits
                 put in tracking on the strip charts
                 cleanup
 
                                               TJB 28 Jul 11

*/

import java.awt.*;
import java.lang.Math ;
import java.awt.event.*;

public class Drop extends java.applet.Applet {
 
   static double convdr = 3.1415926/180. ;
   static double pid2 = 3.1415926/2.0 ;
   static double pi = 3.1415926 ;
   static double zero = 0.0 ;
   static double wtzero = 0.00001 ;
 
   int rktype,ntype,part,rtype,fintype,numfin,lunits,planet ;
   int nstage,numeng,nclust,btfair,balob,objtyp ;
   int istab,ifuel,ides,irange,drgmode,wtmode ;
            // body geometry
   static double blngth,blngd,blmax,blmin,bdiam,bdiamd,bdmax,bdmin,brad ;
            // tail fairing geometry
   static double tlngth,tlngd,tlmax,tlmin,tdiam,tdiamd,tdmax,tdmin,trad ;
            // bottle tail fairing
   static double btlngth,btlngd,btlmax,btlmin;
   static double btdiam,btdiamd,btdmax,btdmin,btrad;
            // payload geometry
   static double plngth,plngd,plmax,plmin,pdiam,pdiamd,pdmax,pdmin,prad ;
            // payload fairing geometry
   static double qlngth,qlngd,qlmax,qlmin ;
            // nose geometry
   static double nlngth,nlngd,nlmax,nlmin,ndiam,ndiamd,ndmax,ndmin,nrad ;
   static double nfact,nfact2 ;
            // fin geometry
   static double flngth,flngd,flmax,flmin,fwidth,fwid,fwmax,fwmin,fwex ;
   static double fleang,flemax,flemin,fteang,ftemax,ftemin ;
   static double ftanle,ftante ;
   static double floc,flocd,flcmax,flcmin ;
   static double delt,ap,thet;
   static double[][] finx = new double[3][4] ;
   static double[][] finy = new double[3][4] ;

   static double vmn1,vmn2,vmn3,vmn4,vmn5,vmn6,vmx1,vmx2,vmx3,vmx4,vmx5,vmx6 ;
   static double lconv1,lconv2,fconv,pconv,tconv,tcon0 ;
   static double aconv,dconv2,dconv3,vconv ;
               // weight and materials
   static int mbod,mtfr,mnose,mfin,mpay,mpfr,mbtfr ;
   static double wbod,wtfr,wnose,wpar,wfin,wpay,wpfr,wbtfr,weng,wfuel ;
   static double wbal,wbald,wmax,wmin ;
   static double sabod,satfr,sanose,sapay,sapfr,safin,sabtfr,satot;
   static double pabod,patfr,panose,papay,papfr,pafin,pabtfr,patot;
   static double cabod,canose,capay,catot,carec,caexit,cabexit ;
   static double vbod,vtfr,vnose,vpay,vpfr;
   static double dbod,dtfr,dnose,dfin,dpay,dpfr,dbtfr ;
   static double cgbod,cgtfr,cgnose,cgfin,cgpay,cgpfr,cgbtfr,cgeng,cgfuel ;
   static double cpbod,cptfr,cpnose,cpfin,cppay,cppfr,cpbtfr ;
   static double wobj,wobjd,wobmin,wobmax ;
               // ballistic 
   static double wtd, wtmax,wtmin,cdmin,cdmax,catd,camin,camax ;
   static double vmuzl,vmuzld,vmmax,vmmin ;
               // stomp launcher
   static double sv1,sv1d,sv1min,sv1max,sv2,sv2d,sv2min,sv2max ;
   static double sl,sld,slmin,slmax ;
   static double lpress,volrat,vstomp,presin ;
   static double lpresd,lpresmax,lpresmin ;
              // solid rocket thrust
   static double th1,th2,tim1,tim2,timd;
   static double th1b1,th2b1,tim1b1,tim2b1 ;
            // engine geometry
   static double elngth,ediam,erad,mediam,merad;
   static double b1elngth,b1ediam,b1erad;
            // booster 1 geometry
   static double b1fw,b1fwd,b1fwmax,b1fleang,b1fteang,b1ftanle,b1ftante;
   static double b1lngth,b1lngd,b1lmax,b1flngth,b1flngd;
   static double wengb1,wfuelb1,sab1,pab1,cgb1,cpb1;
   static double wfinb1,safb1,pafb1,cgfb1,cpfb1;
              // bottle rocket thrust
   static double wat,watd,watmin,watmax,fpres,fpresd,fpresmin,fpresmax ;
   static double nozdiam,nozdiamd,nozdmin,nozdmax ;
   static double nozrad,noza,hwat,watrad,volbot ;
   static double ltub,ltubd,ltubmin,ltubmax ;
   static double volair,instair,instwat,instpres,mdot,uexit,lothrust ;
               // flight
   int fire,comp,npt,nsav,nburn,cockflg,cockcal,stepon,step,presopt;
   static int[] npts = new int[5];
   static double weight,drag,thrust,wtflt ;
   static double cg,cp,cd,cdrec ;
   static double g0,q0,ps0,pt0,ts0,rho,rlhum,temf,gama,wtrat,rgas ;
   static double alt,altd,altmax,altmin ;
   static double wind,windd,wndmax,wndmin ;
   static double lnchang,langmax,langmin;
   static double rail,raild,railmin,railmax ;
   static double llaunch,timrail ;
   static double deltim,fltim,vacc,vvel,vloc,hacc,hvel,hloc,spd,vloc0 ;
   static double vmax,hmax,spdmax ;
   static double[][] posx = new double[10][5000] ;
   static double[][] posy = new double[10][5000] ;
   static double[] posa = new double [5000] ;
   static double posb1 ;
       /*  plot & probe data */
   static double fact,facmin,facrat;
   static double facts,facto,factc;
   static int xt,yt,sldloc,viewflg,gridon,lnchgrf,trakon,ldisplay;
   static int xts,yts,slds;
   static int xto,yto,sldo;
   static int xtc,ytc,sldc;

   static double cdNose,cdBody,cdFins;

   Solver solve ;
   View view ;
   Act act ;
   CardLayout layin,layen1,layen2 ;
   Image offImg ;
   Graphics offsGg ;

   public void init() {
     solve = new Solver() ;

     offImg = createImage(this.size().width,
                      this.size().height) ;
     offsGg = offImg.getGraphics() ;

     setLayout(new GridLayout(1,2,5,5)) ;

     view = new View(this) ;
     act = new Act(this) ;

     add(view) ;
     add(act) ;

     solve.setDefaults () ;
     loadInput() ;

     solve.comPute () ;

     view.start() ;
  }
 
  public Insets insets() {
     return new Insets(5,5,5,5) ;
  }

  public int filter0(double inumbr) {
        //  output only to .
       int number ;
       int intermed ;
 
       number = (int) (inumbr);
       return number ;
  }

  public float filter1(double inumbr) {
     //  output only to .1
       float number ;
       int intermed ;
 
       intermed = (int) (inumbr * 10.) ;
       number = (float) (intermed / 10. );
       return number ;
  }
 
  public float filter3(double inumbr) {
     //  output only to .001
       float number ;
       int intermed ;
 
       intermed = (int) (inumbr * 1000.) ;
       number = (float) (intermed / 1000. );
       return number ;
  }
 
  public float filter5(double inumbr) {
     //  output only to .00001
       float number ;
       int intermed ;
 
       intermed = (int) (inumbr * 100000.) ;
       number = (float) (intermed / 100000. );
       return number ;
  }

  public void setDesignView() {   // initial design view
       viewflg = 0 ;
       lnchgrf = 0 ;
       fact = facto = 20.25;
       if (rktype == 2) fact = facto = 12.0;
       facmin = .25 ;
       facrat = .20 ;
       xt = xto = 170; 
       yt = yto = 420 ;
       if (rktype == 2) yt = yto = 370 ;
       sldloc = sldo = 250;
       if (rktype == 2) sldloc = sldo = 290;
  }
 
  public void restDesignView() {   // restore design view
       viewflg = 0 ;
       lnchgrf = 0 ;
       fact = facto ;
       facmin = .25 ;
       facrat = .20 ;
       xt = xto ; 
       yt = yto ;
       sldloc = sldo ;
  }
 
  public void setRangeView() {   // initial range view
       viewflg = 1 ;
       facts = fact = 2.01;
       facmin = .01 ;
       facrat = .02 ;
       xts = xt = 190; 
       yts = yt =420 ;
       slds = sldloc= 250;
  }
 
  public void restRangeView() {   // restore range view
       viewflg = 1 ;
       fact = facts ;
       facmin = .01 ;
       facrat = .02 ;
       xt = xts ; 
       yt = yts ;
       sldloc = slds ;
  }
 
  public void setGraphView() {   // initial graph view
       viewflg = 2 ;
       factc = fact = 1.25;
       facmin = .01 ;
       facrat = .02 ;
       xtc = xt = 100; 
       ytc = yt = 60 ;
       sldc = sldloc= 288;
  }
 
  public void restGraphView() {   // restore graph view
       viewflg = 2 ;
       fact = factc ;
       facmin = .01 ;
       facrat = .02 ;
       xt = xtc ; 
       yt = ytc ;
       sldloc = sldc ;
  }
 
  public void loadBallistic() {   // load Ballistic info
    // ballisitic shell
       rktype = 10 ;
       fire = 0 ;
       comp = 0 ;
       tim1 = .2 ;
       weng = 0.0;
       wfuel = 0.0 ;
       nstage = 1; 
       cg = 0.0 ;
       cp = 0.0 ;
       balob = 0 ;
       weight = 2.0 ;
       wtd = weight * fconv;
       wtmin = 0.1 * fconv ;  wtmax = 1600 * fconv ;
       cd = .7 ;
       cdmin = 0.0 ;  cdmax = 5.0 ;
       catot = 1.0 ;
       catd = catot * aconv ;
       camin = 0.0 ;  camax = 250.0 * aconv ;
       vmuzl = 0.0 ; 
       vmuzld = vmuzl * lconv1 ; 
       vmmin = -100.0*lconv1 ;  vmmax = 100. * lconv1 ;
  }

  public void loadInput() {   // load the input panels
       String outden2,outden3,outlng,outfor ;
       int i1,i2,i3,i4,i5,i6 ;
       double v1,v2,v3,v4,v5,v6 ;
       float fl1,fl2,fl3,fl4,fl5,fl6 ;

       outden2 = " oz/in2" ;
       if (lunits == 1) outden2 = " g/cs" ;
       outden3 = " oz/in3" ;
       if (lunits == 1) outden3 = " g/cc" ;
       outlng = " in" ;
       if (lunits == 1) outlng = " cm" ;
       outfor = " oz" ;
       if (lunits == 1) outfor = " g" ;

     // ballisitic shell
       v1 = wtd ;
       vmn1 = wtmin; vmx1 = wtmax ;
       v2 = cd ;
       vmn2 = cdmin; vmx2 = cdmax ;
       v3 = catd ;
       vmn3 = camin; vmx3 = camax ;
       v4 = vmuzld ;
       vmn4 = vmmin; vmx4 = vmmax ;
       v5 = windd ;
       vmn5 = wndmin;  vmx5 = wndmax ;
       v6 = altd ;
       vmn6 = altmin;  vmx6 = altmax ;

       act.bali.lt.f1.setText(String.valueOf(filter3(wtd))) ;
       act.bali.lt.f2.setText(String.valueOf(filter3(cd))) ;
       act.bali.lt.f3.setText(String.valueOf(filter3(catd))) ;
       act.bali.lt.f4.setText(String.valueOf(filter3(vmuzld))) ;
       act.bali.lt.f5.setText(String.valueOf(filter3(windd))) ;
       act.bali.lt.f6.setText(String.valueOf(filter0(altd))) ;

       i1 = (int) (((v1 - vmn1)/(vmx1-vmn1))*1000.) ;
       i2 = (int) (((v2 - vmn2)/(vmx2-vmn2))*1000.) ;
       i3 = (int) (((v3 - vmn3)/(vmx3-vmn3))*1000.) ;
       i4 = (int) (((v4 - vmn4)/(vmx4-vmn4))*1000.) ;
       i5 = (int) (((v5 - vmn5)/(vmx5-vmn5))*1000.) ;
       i6 = (int) (((v6 - vmn6)/(vmx6-vmn6))*1000.) ;

       act.bali.rt.s1.setValue(i1) ;
       act.bali.rt.s2.setValue(i2) ;
       act.bali.rt.s3.setValue(i3) ;
       act.bali.rt.s4.setValue(i4) ;
       act.bali.rt.s5.setValue(i5) ;
       act.bali.rt.s6.setValue(i6) ;

       return ;
  }

  public void loadOut() {   // output routine
     String outfor,outvel,outlng,outhi ;

     outfor = " oz" ;
     if (lunits == 1) outfor = " g" ;
     outlng = " in" ;
     if (lunits == 1) outlng = " cm" ;
     outhi = " ft" ;
     if (lunits == 1) outhi = " m" ;
     outvel = " ft/s" ;
     if (lunits == 1) outvel = " m/s" ;

     return ;
  } 
 
  class Solver {
 
     Solver () {
     }

     public void setDefaults() {
 
    // units
       lunits = 0 ;
       dconv2 = 1.0 ;
       dconv3 = 1.0 ;
       lconv1 = 1.0 ;
       lconv2 = 1.0 ;
       aconv = 1.0 ;
       vconv = 1.0 ;
       fconv = 1.0 ;
       pconv = 1.0 ;
       tconv = 1.0 ;
       tcon0 = 459.0 ;

       nsav = 0 ;

       planet = 0 ;
       g0 = 32.2 ;
       altd = alt = 5000.0 ;
       altmin = 0.0;  altmax = 100000. ;
       ps0 = 14.7 ;
       rgas = 1718. ;
       getAtmos() ;

       presin = 14.7 ;
       loadBallistic() ;

       part = 3 ;
       istab = 1 ;
       ifuel = 1 ;
       ides = 1 ;
       irange = 1 ;
       stepon = 0 ;
       step = 0 ;

    // launch
       windd = wind = 0.0 ;
       wndmin = -20.0 ; wndmax = 20.0 ;
       lnchang = 0.0 ;
       langmin = -60.0 ;  langmax = 60.0 ;
       raild = rail = 3.0 ;
       railmin = 1.0; railmax = 5.0 ;
       cockflg = 0 ;
       presopt = 0 ;
       vloc0 = 5000.0 ;

       posa[0] = pid2 ;

       fire = 0 ;
       comp = 0 ;
       vacc = 0.0 ; vvel = 0.0 ; vloc = 0.0 ;
       hacc = 0.0 ; hvel = 0.0 ; hloc = 0.0 ;
       vmax = 0.0 ; hmax = 0.0 ; 
       spd = 0.0 ; spdmax = 0.0 ;

         // graphics
       viewflg = 2 ;
       ldisplay = 1 ;
       gridon = 1 ;
       trakon = -1 ;
       setGraphView() ;

       drgmode = 0 ;  // compute drag
       cdNose = 0;
       cdBody = 0;
       cdFins = 0;

       wtmode = 0 ;  //compute weight
       wtmin = 0.1 * fconv ;  wtmax = 1600 * fconv ;

 //      getWtCgCp() ;
       return ;
     }

     public void getWtCgCp() {

       weight = wnose + wbod + wtfr + wbal + wpar + wpay + wpfr + wfin
                + weng + wfuel ;
       patot = panose + pabod + patfr + papay + papfr + pafin ;

       cg = ( (wbod * cgbod) 
            + (weng * (cgeng - tlngth))
            + (wfuel *(cgfuel - tlngth))
            - (wtfr * cgtfr) 
            + ((wbal + wpar) * (blngth + qlngth + plngth))
            + (wpay * (blngth + qlngth + cgpay)) 
            + (wpfr * (blngth + cgpfr))
            + (wfin * (floc + cgfin))
            + (wnose * (blngth + qlngth + plngth + cgnose))
            ) / weight ;
       cp = ( (pabod * cpbod)  
            - (patfr * cptfr) 
            + (papay * (blngth + qlngth + cppay))
            + (papfr * (blngth + cppfr))
            + (pafin * (floc + cpfin))
            + (panose * (blngth + qlngth + plngth + cpnose))
            ) / patot ;

       if (rktype < 2 || rktype > 2) {
          if (cg >= cp) {
             istab = 1 ;
          }
          if (cg < cp) {
             istab = 0 ;
          }
       }
 
 // special for 2 stage solid rocket
       if (nstage == 2) {   
          weight = weight + wengb1 + wfuelb1 + wfinb1 ;
          patot = patot + pab1 + pafb1 ;
          cg = ( (wbod * cgbod) 
            + (weng * (cgeng - tlngth))
            + (wfuel *(cgfuel - tlngth))
            - (wtfr * cgtfr) 
            + ((wbal + wpar) * (blngth + qlngth + plngth))
            + (wpay * (blngth + qlngth + cgpay)) 
            + (wpfr * (blngth + cgpfr))
            + (wfin * (floc + cgfin))
            + (wnose * (blngth + qlngth + plngth + cgnose))
            - ((wengb1 + wfuelb1) * (cgb1 + tlngth))
            - (wfinb1 * (cgfb1 + tlngth))
            ) / weight ;
          cp = ( (pabod * cpbod)  
            - (patfr * cptfr) 
            + (papay * (blngth + qlngth + cppay))
            + (papfr * (blngth + cppfr))
            + (pafin * (floc + cpfin))
            + (panose * (blngth + qlngth + plngth + cpnose))
            - (pab1 * (cpb1 + tlngth))
            - (pafb1 * (cpfb1 + tlngth))
            ) / patot ;
          if (cg >= cp) {
             istab = 1 ;
          }
          if (cg < cp) {
             istab = 0 ;
          }
       }

    // special for bottle rocket
       if (rktype == 2) { 
          weight = weight - wtfr ;
          patot = patot - patfr;
          cg = ( (wbod * cgbod) 
            + (weng * cgeng)
            + (wfuel * cgfuel)
            + ((wbal + wpar) * (blngth + qlngth + plngth))
            + (wpay * (blngth + qlngth + cgpay)) 
            + (wpfr * (blngth + cgpfr))
            + (wfin * (floc + cgfin))
            + (wnose * (blngth + qlngth + plngth + cgnose))
            ) / weight ;
          cp = ( (pabod * cpbod)  
            + (papay * (blngth + qlngth + cppay))
            + (papfr * (blngth + cppfr))
            + (pafin * (floc + cpfin))
            + (panose * (blngth + qlngth + plngth + cpnose))
            ) / patot ;

          if (btfair == 1) {
             weight = weight + wbtfr ;
             patot = patot + pabtfr;
             cg = ( (wbod * cgbod) 
               + (weng * cgeng)
               + (wbtfr * (4.0 - cgbtfr))
               + (wfuel * cgfuel)
               + ((wbal + wpar) * (blngth + qlngth + plngth))
               + (wpay * (blngth + qlngth + cgpay)) 
               + (wpfr * (blngth + cgpfr))
               + (wfin * (floc + cgfin))
               + (wnose * (blngth + qlngth + plngth + cgnose))
               ) / weight ;
             cp = ( (pabod * cpbod)  
               + (pabtfr * (4.0 - cpbtfr))
               + (papay * (blngth + qlngth + cppay))
               + (papfr * (blngth + cppfr))
               + (pafin * (floc + cpfin))
               + (panose * (blngth + qlngth + plngth + cpnose))
               ) / patot ;
          }

          if (cg >= cp) {
             istab = 1 ;
          }
          if (cg < cp) {
             istab = 0 ;
          }
          if (lothrust > (weight * wtrat)) {
             ifuel = 1;
          }
          if (lothrust <= (weight * wtrat)) {
             ifuel = 0 ;
          }
       }
 
    // special for solid rocket
       if (rktype == 3) { 
          if (nstage == 1) lothrust = 16.0 * th1 ;
          if (nstage == 2) lothrust = 16.0 * th1b1 ;

          if (lothrust > (weight * wtrat)) {
             ifuel = 1 ;
          }
          if (lothrust <= (weight * wtrat)) {
             ifuel = 0 ;
          }
       }
    // cross-sectional area
       catot = cabod ; 
       if ((canose > catot) && (ntype < 4)) catot = canose ;
       if ((capay > catot) && (plngth > .01)) catot = capay ;

       wtflt = weight * wtrat ;

       return ;
     }
 
     public void getAtmos() {    //  atmospheric conditions
     double hite,pvap ;    

       g0 = 32.2 ;
       rgas = 1718. ;                /* ft2/sec2 R */
       gama = 1.4 ;
//       hite = alt ;
       hite = vloc ;
       wtrat = 1.0 ;
       if (planet <= 1) {    // Earth  standard day
          // Earth  standard day
          if (hite <= 36152.) {           // Troposphere
             ts0 = 518.6 - 3.56 * hite/1000. ;
             ps0 = 2116. * Math.pow(ts0/518.6,5.256) ;
          }
          if (hite >= 36152. && hite <= 82345.) {   // Stratosphere
             ts0 = 389.98 ;
             ps0 = 2116. * .2236 *
                  Math.exp((36000.-hite)/(53.35*389.98)) ;
          }
          if (hite >= 82345.) {
             ts0 = 389.98 + 1.645 * (hite-82345)/1000. ;
             ps0 = 2116. *.02456 * Math.pow(ts0/389.98,-11.388) ;
          } 
       }
       if (planet == 3) {   // Mars - curve fit of orbiter data
         rgas = 1149. ;                /* ft2/sec2 R */
         gama = 1.29 ;
         wtrat = .38 ;

         if (hite <= 22960.) {
            ts0 = 434.02 - .548 * hite/1000. ;
            ps0 = 14.62 * Math.pow(2.71828,-.00003 * hite) ;
         }
         if (hite > 22960.) {
            ts0 = 449.36 - 1.217 * hite/1000. ;
            ps0 = 14.62 * Math.pow(2.71828,-.00003 * hite) ;
         }
       }

       rho = ps0/(rgas * ts0) ;
       if (planet == 1) rho = 0.0 ;   // Earth no drag
       ps0 = ps0 / 144. ;   // psi

       if (planet == 2) {     // Moon
          wtrat = .1667 ;
          gama = 1.4 ;
          ps0 = 0.0 ;
          rho = 0.0 ;
       }
       fpresmin = ps0 * pconv ;
       lpresmin = ps0 * pconv ;

       loadInput() ;

       return ;
     }

     public void comPute() {
 
       if (rktype <= 9) {
          if (wtmode == 0) getWtCgCp() ;

          if (wtmode ==1) {
              istab = 2 ;
              weight = wbod + weng + wfuel ;
          }

       }

       loadOut() ;

       return ;
     }
  }

  class Act extends Panel {
     Drop outerparent ;
     Lnch lnch ;
     Bali bali ;

     Act (Drop target) {

       outerparent = target ;
       setLayout(new GridLayout(2,1,5,5)) ;

       lnch = new Lnch(outerparent) ;
       bali = new Bali(outerparent) ;

       add(bali) ;
       add(lnch) ;
    }

    class Lnch extends Panel {
          Drop outerparent ;                           
          TextField o1,o2,o3,o4 ;
          Choice untch ;
          Button bt1,bt2,bt3,bt4,bt5,bt6,bt7,bt8 ;
          TextField o5,o6,o7,o8,o9,o10,o11,o12 ;
          Label lab1, lab2, lab3, lab9, lab10, lab10a, l11,l12 ;

          Lnch (Drop target) {
  
            outerparent = target ;
            setLayout(new GridLayout(7,5,2,5)) ;   

            lab9 = new Label("DropSim", Label.RIGHT) ;
            lab9.setForeground(Color.red) ;
            lab10 = new Label("Version",Label.RIGHT) ;
            lab10.setForeground(Color.red) ;
            lab10a = new Label("1.0e",Label.LEFT) ;
            lab10a.setForeground(Color.red) ; 

            untch = new Choice() ;
            untch.setBackground(Color.white) ;
            untch.setForeground(Color.blue) ;
            untch.addItem("Imperial") ;
            untch.addItem("Metric") ;
            untch.select(0) ;    

            lab1 = new Label("Flight ",Label.RIGHT) ;
            lab1.setForeground(Color.red) ;

            lab2 = new Label("Control",Label.LEFT) ;
            lab2.setForeground(Color.red) ;

            lab3 = new Label("Telemetry",Label.LEFT) ;
            lab3.setForeground(Color.red) ;

            o1 = new TextField(String.valueOf((float)zero),5) ;
            o1.setBackground(Color.black) ;
            o1.setForeground(Color.green) ;

            o2 = new TextField(String.valueOf((float)zero),5) ;
            o2.setBackground(Color.black) ;
            o2.setForeground(Color.green) ;
     
            o3 = new TextField(String.valueOf((float)zero),5) ;
            o3.setBackground(Color.black) ;
            o3.setForeground(Color.green) ;
     
            o4 = new TextField(String.valueOf((float)zero),5) ;
            o4.setBackground(Color.black) ;
            o4.setForeground(Color.green) ;

            bt3 = new Button("Pause") ;
            bt3.setBackground(Color.blue) ;
            bt3.setForeground(Color.white) ;
 
            bt5 = new Button("Drop") ;
            bt5.setBackground(Color.white) ;
            bt5.setForeground(Color.blue) ;
 
            bt4 = new Button("Reset") ;
            bt4.setBackground(Color.blue) ;
            bt4.setForeground(Color.white) ;
 
            bt6 = new Button("Abort") ;
            bt6.setBackground(Color.red) ;
            bt6.setForeground(Color.white) ;
 
            bt7 = new Button("Data") ;
            bt7.setBackground(Color.blue) ;
            bt7.setForeground(Color.white) ;
 
            bt8 = new Button("Step") ;
            bt8.setBackground(Color.blue) ;
            bt8.setForeground(Color.white) ;
 
            o5 = new TextField(String.valueOf((float)zero),5) ;
            o5.setBackground(Color.black) ;
            o5.setForeground(Color.yellow) ;
     
            o6 = new TextField(String.valueOf((float)zero),5) ;
            o6.setBackground(Color.black) ;
            o6.setForeground(Color.yellow) ;
     
            o7 = new TextField(String.valueOf((float)zero),5) ;
            o7.setBackground(Color.black) ;
            o7.setForeground(Color.yellow) ;

            o8 = new TextField(String.valueOf((float)zero),5) ;
            o8.setBackground(Color.black) ;
            o8.setForeground(Color.green) ;

            o9 = new TextField(String.valueOf((float)zero),5) ;
            o9.setBackground(Color.black) ;
            o9.setForeground(Color.green) ;

            o10 = new TextField(String.valueOf((float)zero),5) ;
            o10.setBackground(Color.black) ;
            o10.setForeground(Color.green) ;

            l11 = new Label("Pressure ",Label.RIGHT) ;
            o11 = new TextField(String.valueOf((float)zero),5) ;
            o11.setBackground(Color.black) ;
            o11.setForeground(Color.green) ;

            l12 = new Label("Temperature",Label.RIGHT) ;
            o12 = new TextField(String.valueOf((float)zero),5) ;
            o12.setBackground(Color.black) ;
            o12.setForeground(Color.green) ;

            add(lab1) ;
            add(lab2) ;
            add(bt5) ;
            add(bt4) ;
            add(bt6) ;

            add(new Label(" ", Label.CENTER)) ;
            add(lab3) ;
            add(new Label("Height", Label.CENTER)) ;
            add(new Label("Speed", Label.CENTER)) ;
            add(new Label("Range", Label.CENTER)) ;

            add(new Label("Time", Label.CENTER)) ;
            add(new Label("Current ", Label.RIGHT)) ;
            add(o2) ;
            add(o3) ;
            add(o4) ;

            add(o1) ;
            add(new Label("Maximum", Label.RIGHT)) ;
            add(o5) ;
            add(o6) ;
            add(o7) ;

            add(bt3) ;
            add(new Label("Weight", Label.RIGHT)) ;
            add(o10) ;
            add(new Label("Drag", Label.RIGHT)) ;
            add(o9) ;

            add(bt8) ;
            add(l11) ;
            add(o11) ;
            add(l12) ;
            add(o12) ;

            add(lab9) ;
            add(lab10) ;
            add(lab10a) ;
            add(new Label("Units:", Label.RIGHT)) ;
            add(untch) ;
          }

          public boolean action(Event evt, Object arg) {
            if(evt.target instanceof Choice) {
               this.handleCho(evt,arg) ;
               return true ;
            }
            if(evt.target instanceof Button) {
               this.handleBut(evt,arg) ;
               return true ;
            }
            else return false ;
          }

       public void handleCho(Event evt, Object obj) {
         String label = (String)obj ;

         if(label.equals("Imperial")) {
            lunits = 0 ;
            setUnits () ;
         }
         if(label.equals("Metric")) {
            lunits = 1 ;
            setUnits () ;
         }

         solve.comPute() ;
       }
 
       public void setUnits() {   // Switching Units
         String outfor,outht,outspd ;
         double alts,altmxs,rals,ralmns,ralmxs,wnds,wndmns,wndmxs ;
         double vmzs,vmzmxs,vmzmns,cats,catmxs,catmns;
         double wtns,wtmns,wtmxs,lprns,lprmns,lprmxs ;
         double blns,blmns,blmxs,bdms,bdmns,bdmxs ;
         double btlns,btlmns,btlmxs,btdms,btdmns,btdmxs ;
         double tlns,tlmns,tlmxs,tdms,tdmns,tdmxs ;
         double plns,plmns,plmxs,pdms,pdmns,pdmxs,qlns,qlmns,qlmxs ;
         double nlns,nlmns,nlmxs,ndms,ndmns,ndmxs ;
         double wbns,wbmns,wbmxs,fpns,fpmns,fpmxs ;
         double flns,flmns,flmxs,fwdms,fwdmns,fwdmxs,flons,flomns,flomxs ;
         double sv1ns,sv1mns,sv1mxs,sv2ns,sv2mns,sv2mxs,slns,slmns,slmxs ;
         double watns,watmns,watmxs,nzdns,nzdmns,nzdmxs,ltns,ltmns,ltmxs ;
         double b1flns,b1flmxs,b1fwdms,b1fwdmxs,b1lns,b1lmxs ;
         double wobjs,wobmxs,wobmns ;
 
         alts = altd / lconv1 ;
         altmxs = altmax / lconv1 ;
         rals = raild / lconv1 ;
         ralmns = railmin / lconv1;
         ralmxs = railmax / lconv1;
         wnds = windd / lconv1 ;
         wndmns = wndmin / lconv1;
         wndmxs = wndmax / lconv1;
         vmzs = vmuzld / lconv1 ;
         vmzmns = vmmin / lconv1;
         vmzmxs = vmmax / lconv1;
         cats = catd / aconv ;
         catmns = camin / aconv;
         catmxs = camax / aconv;
         wtns = wtd / fconv ;
         wtmns = wtmin / fconv;
         wtmxs = wtmax / fconv;
         blns = blngd / lconv2 ;
         blmns = blmin / lconv2;
         blmxs = blmax / lconv2;
         bdms = bdiamd / lconv2 ;
         bdmns = bdmin / lconv2;
         bdmxs = bdmax / lconv2;
         tlns = tlngd / lconv2 ;
         tlmns = tlmin / lconv2;
         tlmxs = tlmax / lconv2;
         tdms = tdiamd / lconv2 ;
         tdmns = tdmin / lconv2;
         tdmxs = tdmax / lconv2;
         plns = plngd / lconv2 ;
         plmns = plmin / lconv2;
         plmxs = plmax / lconv2;
         pdms = pdiamd / lconv2 ;
         pdmns = pdmin / lconv2;
         pdmxs = pdmax / lconv2;
         qlns = qlngd / lconv2 ;
         qlmns = qlmin / lconv2;
         qlmxs = qlmax / lconv2;
         nlns = nlngd / lconv2 ;
         nlmns = nlmin / lconv2;
         nlmxs = nlmax / lconv2;
         ndms = ndiamd / lconv2 ;
         ndmns = ndmin / lconv2;
         ndmxs = ndmax / lconv2;
         wbns = wbald / fconv ;
         wbmns = wmin / fconv;
         wbmxs = wmax / fconv;
         flns = flngd / lconv2 ;
         flmns = flmin / lconv2;
         flmxs = flmax / lconv2;
         fwdms = fwid / lconv2 ;
         fwdmns = fwmin / lconv2;
         fwdmxs = fwmax / lconv2;
         flons = flocd / lconv2 ;
         flomns = flcmin / lconv2;
         flomxs = flcmax / lconv2;
         btlns = btlngd / lconv2 ;
         btlmns = btlmin / lconv2;
         btlmxs = btlmax / lconv2;
         btdms = btdiamd / lconv2 ;
         btdmns = btdmin / lconv2;
         btdmxs = btdmax / lconv2;
         sv1ns = sv1d / vconv ;
         sv1mns = sv1min / vconv;
         sv1mxs = sv1max / vconv;
         sv2ns = sv2d / vconv ;
         sv2mns = sv2min / vconv;
         sv2mxs = sv2max / vconv;
         slns = sld / lconv2 ;
         slmns = slmin / lconv2;
         slmxs = slmax / lconv2;
         lprns = lpresd / pconv ;
         lprmns = lpresmin / pconv ;
         lprmxs = lpresmax / pconv ;
         watns = watd / vconv ;
         watmns = watmin / vconv;
         watmxs = watmax / vconv;
         nzdns = nozdiamd / lconv2 ;
         nzdmns = nozdmin / lconv2;
         nzdmxs = nozdmax / lconv2;
         fpns = fpresd / pconv ;
         fpmns = fpresmin / pconv ;
         fpmxs = fpresmax / pconv ;
         ltns = ltubd / lconv2 ;
         ltmns = ltubmin / lconv2;
         ltmxs = ltubmax / lconv2;
         b1flns = b1flngd / lconv2 ;
         b1fwdms = b1fwd / lconv2 ;
         b1fwdmxs = b1fwmax / lconv2;
         b1lns = b1lngd / lconv2 ;
         b1lmxs = b1lmax / lconv2;
         wobjs = wobjd / fconv ;
         wobmxs = wobmax / fconv ;
         wobmns = wobmin / fconv ;

         switch (lunits) {
            case 0:{                   /* Imperial Units */
                 outfor = " oz" ; outht = " ft"; outspd = " fps";
                 lconv1 = 1.0 ; lconv2 = 1.0 ; fconv = 1.0 ; 
                 pconv  = 1.0 ; tconv  = 1.0 ; tcon0 = 459.0 ;

                 act.bali.lt.l6.setText("Altitude-ft") ;
                 act.bali.lt.l5.setText("Wind fps") ;
                 act.bali.lt.l1.setText(" Weight oz") ;
                 act.bali.lt.l3.setText("Area sq in") ;
                 act.bali.lt.l4.setText("Speed fps") ;
                 act.lnch.o2.setText(String.valueOf(filter0(vloc*lconv1))+outht) ;
                 act.lnch.o3.setText(String.valueOf(filter0(spd*lconv1))+outspd) ;
                 act.lnch.o4.setText(String.valueOf(filter0(posx[nsav][npt] * lconv1))+outht);
                 act.lnch.o5.setText(String.valueOf(filter0(vmax*lconv1))+outht) ;
                 act.lnch.o7.setText(String.valueOf(filter0(hmax*lconv1))+outht) ;
                 act.lnch.o6.setText(String.valueOf(filter0(spdmax*lconv1))+outspd) ;

                 break ;
            }
            case 1:{                   /* Metric Units */
                 outfor = " g" ; outht = " m"; outspd = " mps";
                 lconv1 = .3048 ; lconv2 = 2.54 ; fconv = 28.35 ;
                 pconv  = 6.891 ; tconv = .5555 ; tcon0 = 273. ; 

                 act.bali.lt.l6.setText("Altitude-m") ;
                 act.bali.lt.l5.setText("Wind mps") ;
                 act.bali.lt.l1.setText(" Weight g") ;
                 act.bali.lt.l3.setText("Area sq cm") ;
                 act.bali.lt.l4.setText("Speed mps") ;
                 act.lnch.o2.setText(String.valueOf(filter0(vloc*lconv1))+outht) ;
                 act.lnch.o3.setText(String.valueOf(filter0(spd*lconv1))+outspd) ;
                 act.lnch.o4.setText(String.valueOf(filter0(posx[nsav][npt] * lconv1))+outht);
                 act.lnch.o5.setText(String.valueOf(filter0(vmax*lconv1))+outht) ;
                 act.lnch.o7.setText(String.valueOf(filter0(hmax*lconv1))+outht) ;
                 act.lnch.o6.setText(String.valueOf(filter0(spdmax*lconv1))+outspd) ;

                 break ;
            }
          }
          aconv = lconv2 * lconv2 ;
          vconv = aconv * lconv2 ;
          dconv2 = fconv / aconv ;
          dconv3 = fconv / vconv ;
 
          altd = alts * lconv1 ;
          altmax = altmxs * lconv1 ;
          raild = rals * lconv1 ;
          railmin = ralmns * lconv1 ;
          railmax = ralmxs * lconv1 ;
          windd = wnds * lconv1 ;
          wndmin = wndmns * lconv1 ;
          wndmax = wndmxs * lconv1 ;
          vmuzld = vmzs * lconv1 ;
          vmmin = vmzmns * lconv1 ;
          vmmax = vmzmxs * lconv1 ;
          catd = cats * aconv ;
          camin = catmns * aconv ;
          camax = catmxs * aconv ;
          wtd = wtns * fconv ;
          wtmin = wtmns * fconv ;
          wtmax = wtmxs * fconv ;
          blngd = blns * lconv2 ;
          blmin = blmns * lconv2 ;
          blmax = blmxs * lconv2 ;
          bdiamd = bdms * lconv2 ;
          bdmin = bdmns * lconv2 ;
          bdmax = bdmxs * lconv2 ;
          tlngd = tlns * lconv2 ;
          tlmin = tlmns * lconv2 ;
          tlmax = tlmxs * lconv2 ;
          tdiamd = tdms * lconv2 ;
          tdmin = tdmns * lconv2 ;
          tdmax = tdmxs * lconv2 ;
          plngd = plns * lconv2 ;
          plmin = plmns * lconv2 ;
          plmax = plmxs * lconv2 ;
          pdiamd = pdms * lconv2 ;
          pdmin = pdmns * lconv2 ;
          pdmax = pdmxs * lconv2 ;
          qlngd = qlns * lconv2 ;
          qlmin = qlmns * lconv2 ;
          qlmax = qlmxs * lconv2 ;
          nlngd = nlns * lconv2 ;
          nlmin = nlmns * lconv2 ;
          nlmax = nlmxs * lconv2 ;
          ndiamd = ndms * lconv2 ;
          ndmin = ndmns * lconv2 ;
          ndmax = ndmxs * lconv2 ;
          wbald = wbns * fconv ;
          wmin = wbmns * fconv ;
          wmax = wbmxs * fconv ;
          flngd = flns * lconv2 ;
          flmin = flmns * lconv2 ;
          flmax = flmxs * lconv2 ;
          fwid = fwdms * lconv2 ;
          fwmin = fwdmns * lconv2 ;
          fwmax = fwdmxs * lconv2 ;
          flocd = flons * lconv2 ;
          flcmin = flomns * lconv2 ;
          flcmax = flomxs * lconv2 ;
          btlngd = btlns * lconv2 ;
          btlmin = btlmns * lconv2 ;
          btlmax = btlmxs * lconv2 ;
          btdiamd = btdms * lconv2 ;
          btdmin = btdmns * lconv2 ;
          btdmax = btdmxs * lconv2 ;
          sv1d = sv1ns * vconv ;
          sv1min = sv1mns * vconv ;
          sv1max = sv1mxs * vconv ;
          sv2d = sv2ns * vconv ;
          sv2min = sv2mns * vconv ;
          sv2max = sv2mxs * vconv ;
          sld = slns * lconv2 ;
          slmin = slmns * lconv2 ;
          slmax = slmxs * lconv2 ;
          lpresd = lprns * pconv ;
          lpresmin = lprmns * pconv ;
          lpresmax = lprmxs * pconv ;
          watd = watns * vconv ;
          watmin = watmns * vconv ;
          watmax = watmxs * vconv ;
          nozdiamd = nzdns * lconv2 ;
          nozdmin = nzdmns * lconv2 ;
          nozdmax = nzdmxs * lconv2 ;
          fpresd = fpns * pconv ;
          fpresmin = fpmns * pconv ;
          fpresmax = fpmxs * pconv ;
          ltubd = ltns * lconv2 ;
          ltubmin = ltmns * lconv2 ;
          ltubmax = ltmxs * lconv2 ;
          b1flngd  = b1flns * lconv2 ;
          b1fwd = b1fwdms * lconv2 ;
          b1fwmax = b1fwdmxs * lconv2;
          b1lngd = b1lns * lconv2 ;
          b1lmax = b1lmxs * lconv2;
          wobjd = wobjs * fconv ;
          wobmax = wobmxs * fconv ;
          wobmin = wobmns * fconv ;
               // change input and output 
          loadOut () ;
          loadInput () ;
  
          return ;
       }

          public void handleBut(Event evt, Object obj) {
            String label = (String)obj ;
            int i,j ;
            double angle ;

            if(label.equals("Pause")) {
              comp = 0 ;
              stepon = 1;
              step = 0 ;
              bt3.setLabel("Resume") ;
              bt3.setBackground(Color.white) ;
              bt3.setForeground(Color.blue) ;
              bt8.setBackground(Color.white) ;
              bt8.setForeground(Color.blue) ;
            }
            if(label.equals("Resume")) {
              comp = 1 ;
              stepon = 0 ;
              bt3.setLabel("Pause") ;
              bt3.setBackground(Color.blue) ;
              bt3.setForeground(Color.white) ;
              bt8.setBackground(Color.blue) ;
              bt8.setForeground(Color.white) ;
            }
            if(label.equals("Step")) {
              step = 1 ;
            }
            if(label.equals("Reset")) {
              fire = 0 ;
              comp = 0 ;
              stepon = 0 ;
              ifuel =1 ;
              ides = 1 ;
              irange = 1 ;
              for (i=0; i<=npts[nsav]; ++i){
                 posx[nsav][i] = 0.0 ;  
                 posy[nsav][i] = 0.0 ;  
                 posa[i] = pid2 ;
                 posb1 = 0.0 ;
              }
              npts[nsav] = 0 ;
              bt5.setBackground(Color.white) ;
              bt5.setForeground(Color.blue) ;
              bt3.setLabel("Pause") ;
              bt3.setBackground(Color.blue) ;
              bt3.setForeground(Color.white) ;
              bt8.setBackground(Color.blue) ;
              bt8.setForeground(Color.white) ;
            }
            if(label.equals("Drop")) {
              if (ifuel == 1 && ides == 1 && irange ==1 && istab >=1 ) {
                 bt5.setBackground(Color.yellow) ;
                 bt5.setForeground(Color.black) ;
                 fire = 1 ;
                 comp = 1 ;
                 cockcal = 0 ;
                 fltim = -5.0 ;
                 drag = 0.0 ;
                 timrail = 0.0 ;
                 if (rktype == 10) {
                    spd = vmuzl ;
                    llaunch = 0.0 ;
                    drag = (16.0 * cd * .5 * rho * catot * spd * spd / 144.) ; 
                    angle = (90.0 - lnchang) * convdr ;
                    vacc = (-drag*Math.sin(angle)-(weight*wtrat))/(weight/g0) ;
                    hacc = (-drag*Math.cos(angle)) / (weight/g0)  ;
                    cockflg = 0 ;
                 }
                 if (rktype == 1) {
                    spd = vstomp ;
                    llaunch = sl / 12.0 ;
                    drag = (16.0 * cd * .5 * rho * catot * spd * spd / 144.) ; 
                    angle = (90.0 - lnchang) * convdr ;
                    vacc = (-drag*Math.sin(angle)-(weight*wtrat))/(weight/g0) ;
                    hacc = (-drag*Math.cos(angle)) / (weight/g0)  ;
                 }
                 if (rktype == 2) {
                    spd = 0.0 ;
                    llaunch = ltub / 12.0  ;
                 }
                 if (rktype == 3) {
                    spd = 0.0 ;
                    llaunch = rail ;
                 }
                 vvel = spd * Math.cos(convdr*lnchang) ;
                 hvel = spd * Math.sin(convdr*lnchang) ;
                 vloc = vloc0 ;
                 hloc = 0.0 ;
                 hmax = 0.0 ;
                 vmax = 0.0 ;
                 spdmax = 0.0 ;
                 npt = 0 ;
                 act.lnch.o1.setForeground(Color.yellow) ;
                 if (viewflg == 2) {
                   for (j=0; j<=4; ++j) {
                      for (i=0; i<=npts[j]; ++i){
                         posx[j][i] = 0.0 ;  
                         posy[j][i] = 0.0 ;  
                       }
                       npts[j] = 0 ;
                    }
                 }
              }
            }
            if(label.equals("Abort")) {
              fire = 0 ;
              comp = 0 ;
              nsav = 0 ;
              for (j=0; j<=4; ++j) {
                 for (i=0; i<=npts[j]; ++i){
                    posx[j][i] = 0.0 ;  
                    posy[j][i] = 0.0 ;  
                    posa[i] = pid2 ;
                    posb1 = 0.0 ;
                 }
                 npts[j] = 0 ;
              }
              irange = 0 ;
              ifuel = 0 ;
              ides = 0 ;
            }
          }  // end handler
       }   // end launch

       class Bali extends Panel {
          Drop outerparent ;
          Lt lt ;
          Rt rt ;
  
          Bali (Drop target) {
  
            outerparent = target ;
            setLayout(new GridLayout(1,2,5,5)) ;
  
            lt = new Lt(outerparent) ;
            rt = new Rt(outerparent) ;

            add(lt) ;
            add(rt) ;
          }

          class Rt extends Panel {
             Drop outerparent ;
             Scrollbar s1,s2,s3,s4,s5,s6;
             Choice obch ;

             Rt (Drop target) {

               int i1,i2,i3,i4,i5,i6 ;
  
               outerparent = target ;
               setLayout(new GridLayout(7,1,10,5)) ;
  
               obch = new Choice() ;
               obch.addItem("Actual Flight") ;
               obch.addItem("Ignore Density Variation -Alt") ;
               obch.addItem("Ignore Density Variation -Ground") ;
               obch.select(0) ;

               i1 = (int) (((wtd - wtmin)/(wtmax-wtmin))*1000.) ;
               i2 = (int) (((cd - cdmin)/(cdmax-cdmin))*1000.) ;
               i3 = (int) (((catd - camin)/(camax-camin))*1000.) ;
               i4 = (int) (((vmuzld - vmmin)/(vmmax-vmmin))*1000.) ;
               i5 = (int) (((windd - wndmin)/(wndmax-wndmin))*1000.) ;
               i6 = (int) (((altd - altmin)/(altmax-altmin))*1000.) ;
  
               s1 = new Scrollbar(Scrollbar.HORIZONTAL,i1,10,0,1000);
               s2 = new Scrollbar(Scrollbar.HORIZONTAL,i2,10,0,1000);
               s3 = new Scrollbar(Scrollbar.HORIZONTAL,i3,10,0,1000);
               s4 = new Scrollbar(Scrollbar.HORIZONTAL,i4,10,0,1000);
               s5 = new Scrollbar(Scrollbar.HORIZONTAL,i5,10,0,1000);
               s6 = new Scrollbar(Scrollbar.HORIZONTAL,i6,10,0,1000);
 
               add(obch) ;
               add(s6) ;
               add(s4) ;
               add(s2) ;
               add(s3) ;
               add(s1) ;
               add(s5) ;
  //             add(new Label(" ", Label.CENTER)) ;
           }
 
           public boolean handleEvent(Event evt) {
               if(evt.id == Event.ACTION_EVENT) {
                  this.handleCho(evt) ;
                  return true ;
               }
               if(evt.id == Event.SCROLL_ABSOLUTE) {
                  this.handleBar(evt) ;
                  return true ;
               }
               if(evt.id == Event.SCROLL_LINE_DOWN) {
                  this.handleBar(evt) ;
                  return true ;
               }
               if(evt.id == Event.SCROLL_LINE_UP) {
                  this.handleBar(evt) ;
                  return true ;
               }
               if(evt.id == Event.SCROLL_PAGE_DOWN) {
                  this.handleBar(evt) ;
                  return true ;
               }
               if(evt.id == Event.SCROLL_PAGE_UP) {
                  this.handleBar(evt) ;
                  return true ;
               }
               else return false ;
          }

          public void handleCho(Event evt) {

             drgmode = obch.getSelectedIndex() ;

             solve.comPute() ;
          }

  
          public void handleBar(Event evt) {     // ballistic shell
             int i1,i2,i3,i4,i5,i6;
             double v1,v2,v3,v4,v5,v6 ;
             float fl1,fl2,fl3,fl4,fl5,fl6 ;

             i1 = s1.getValue() ;
             i2 = s2.getValue() ;
             i3 = s3.getValue() ;
             i4 = s4.getValue() ;
             i5 = s5.getValue() ;
             i6 = s6.getValue() ;

             vmn1 = wtmin;    vmx1 = wtmax ;
             vmn2 = cdmin;    vmx2 = cdmax ;
             vmn3 = camin;    vmx3 = camax ;
             vmn4 = vmmin;    vmx4 = vmmax ;
             vmn5 = wndmin;   vmx5 = wndmax ;
             vmn6 = altmin;   vmx6 = altmax ;

             v1 = i1 * (vmx1 - vmn1)/ 1000. + vmn1 ;
             v2 = i2 * (vmx2 - vmn2)/ 1000. + vmn2 ;
             v3 = i3 * (vmx3 - vmn3)/ 1000. + vmn3 ;
             v4 = i4 * (vmx4 - vmn4)/ 1000. + vmn4 ;
             v5 = i5 * (vmx5 - vmn5)/ 1000. + vmn5 ;
             v6 = i6 * (vmx6 - vmn6)/ 1000. + vmn6 ;
 
             wtd = v1 ;
             weight = wtd / fconv ;
             cd = v2 ;
             cg = 0.0 ;
             cp = 0.0 ;
             catd = v3 ;
             catot = catd / aconv ;
             vmuzld = v4 ;
             vmuzl = vmuzld / lconv1 ;
             windd = v5 ;
             wind = windd / lconv1 ;
             altd = v6 ;
             alt = altd / lconv1 ;
             vloc0 = alt ;
 
             fl1 = filter3(v1) ;
             fl2 = filter3(v2) ;
             fl3 = filter3(v3) ;
             fl4 = filter3(v4) ;
             fl5 = filter3(v5) ;
             fl6 = filter3(v6) ;

             lt.f1.setText(String.valueOf(fl1)) ;
             lt.f2.setText(String.valueOf(fl2)) ;
             lt.f3.setText(String.valueOf(fl3)) ;
             lt.f4.setText(String.valueOf(fl4)) ;
             lt.f5.setText(String.valueOf(fl5)) ;
             lt.f6.setText(String.valueOf(fl6)) ;

             npt = 0 ;

                 ifuel = 1 ;
                 ides = 1;
                 weight = wtd / fconv ;
                 loadOut() ;
                 irange = 1 ;
                 ides = 1;
                 ifuel =1 ;

             solve.getAtmos() ;

             solve.comPute() ;

           }  // end handle
         }  // end right
 
         class Lt extends Panel {
           Drop outerparent ;
           TextField f1, f2, f3, f4, f5, f6 ;
           Label l1, l2, l3, l4, l5, l6, lab ;
  
           Lt (Drop target) {
              outerparent = target ;
              setLayout(new GridLayout(7,2,5,5)) ;

              l1 = new Label(" Weight oz", Label.CENTER) ;
              f1 = new TextField(String.valueOf((float)wtd),5) ;
              f1.setBackground(Color.white) ;
              f1.setForeground(Color.black) ;

              l2 = new Label("Drag Coeff", Label.CENTER) ;
              f2 = new TextField(String.valueOf((float)cd),5) ;
              f2.setBackground(Color.white) ;
              f2.setForeground(Color.black) ;

              l3 = new Label("Area sq in", Label.CENTER) ;
              f3 = new TextField(String.valueOf((float)catd),5) ;
              f3.setBackground(Color.white) ;
              f3.setForeground(Color.black) ;

              l4 = new Label("Speed fps", Label.CENTER) ;
              f4 = new TextField(String.valueOf((float)vmuzld),5) ;
              f4.setBackground(Color.white) ;
              f4.setForeground(Color.black) ;

              l5 = new Label("Wind fps", Label.CENTER) ;
              f5 = new TextField(String.valueOf((float)windd),5) ;
              f5.setBackground(Color.white) ;
              f5.setForeground(Color.black) ;

              l6 = new Label("Altitude-ft", Label.CENTER) ;
              f6 = new TextField("0.0",5) ;
              f6.setBackground(Color.white) ;
              f6.setForeground(Color.black) ;

              add(new Label("Set Initial", Label.RIGHT)) ;
              add(new Label("Conditions", Label.LEFT)) ;

              add(l6) ;
              add(f6) ;

              add(l4) ;
              add(f4) ;

              add(l2) ;
              add(f2) ;

              add(l3) ;
              add(f3) ;

              add(l1) ;
              add(f1) ;

              add(l5) ;
              add(f5) ;

//              add(new Label(" ", Label.CENTER)) ;
//              add(new Label(" ", Label.CENTER)) ;
           }

           public boolean action(Event evt, Object arg) {
             if(evt.target instanceof TextField) {
                 this.handleText(evt,arg) ;
                 return true ;
             }
             else return false ;
           }
    
           public void handleText(Event evt, Object arg) {
             Double V1,V2,V3,V4,V5,V6 ;
             double v1,v2,v3,v4,v5,v6 ;
             int i1,i2,i3,i4,i5,i6 ;
             float fl1 ;

             V1 = Double.valueOf(f1.getText()) ;
             v1 = V1.doubleValue() ;
             V2 = Double.valueOf(f2.getText()) ;
             v2 = V2.doubleValue() ;
             V3 = Double.valueOf(f3.getText()) ;
             v3 = V3.doubleValue() ;
             V4 = Double.valueOf(f4.getText()) ;
             v4 = V4.doubleValue() ;
             V5 = Double.valueOf(f5.getText()) ;
             v5 = V5.doubleValue() ;
             V6 = Double.valueOf(f6.getText()) ;
             v6 = V6.doubleValue() ;

     // weight
             wtd  = v1 ;
             vmn1 = wtmin;   vmx1 = wtmax ;
             if(v1 < vmn1) {
                 wtd = v1 = vmn1 ;
                 fl1 = (float) v1 ;
                 f1.setText(String.valueOf(fl1)) ;
             }
             if(v1 > vmx1) {
                 wtd =  v1 = vmx1 ;
                 fl1 = (float) v1 ;
                 f1.setText(String.valueOf(fl1)) ;
             }
             weight = wtd / fconv ;

     // drag coefficient
             cd  = v2 ;
             vmn2 = cdmin;   vmx2 = cdmax ;
             if(v2 < vmn2) {
                 cd = v2 = vmn2 ;
                 fl1 = (float) v2 ;
                 f2.setText(String.valueOf(fl1)) ;
             }
             if(v2 > vmx2) {
                 cd =  v2 = vmx2 ;
                 fl1 = (float) v2 ;
                 f2.setText(String.valueOf(fl1)) ;
             }

     // cross-sectional area
             catd  = v3 ;
             vmn3 = camin;   vmx3 = camax ;
             if(v3 < vmn3) {
                 catd = v3 = vmn3 ;
                 fl1 = (float) v3 ;
                 f3.setText(String.valueOf(fl1)) ;
             }
             if(v3 > vmx3) {
                 catd =  v3 = vmx3 ;
                 fl1 = (float) v3 ;
                 f3.setText(String.valueOf(fl1)) ;
             }
             catot = catd / aconv ;

     // muzzle velocity
             vmuzld  = v4 ;
             vmn4 = vmmin;   vmx4 = vmmax ;
             if(v4 < vmn4) {
                 vmuzld = v4 = vmn4 ;
                 fl1 = (float) v4 ;
                 f4.setText(String.valueOf(fl1)) ;
             }
             if(v4 > vmx4) {
                 vmuzld =  v4 = vmx4 ;
                 fl1 = (float) v4 ;
                 f4.setText(String.valueOf(fl1)) ;
             }
             vmuzl = vmuzld / lconv1 ;
   // wind
             windd  = v5 ;
             vmn5 = wndmin;   vmx5 = wndmax ;
             if(v5 < vmn5) {
                 windd = v5 = vmn5 ;
                 fl1 = (float) v5 ;
                 f5.setText(String.valueOf(fl1)) ;
             }
             if(v5 > vmx5) {
                 windd =  v5 = vmx5 ;
                 fl1 = (float) v5 ;
                 f5.setText(String.valueOf(fl1)) ;
             }
             wind = windd / lconv1 ;

   // altitude
             altd = v6 ;
             vmn6 = altmin;   vmx6 = altmax ;
             if(v6 < vmn6) {
               altd = v6 = vmn6 ;
               fl1 = (float) v6 ;
               f6.setText(String.valueOf(fl1)) ;
             }
             if(v6 > vmx6) {
               altd = v6 = vmx6 ;
               fl1 = (float) v6 ;
               f6.setText(String.valueOf(fl1)) ;
             }
             alt = altd / lconv1 ;
             vloc0 = alt ;

             i1 = (int) (((v1 - vmn1)/(vmx1-vmn1))*1000.) ;
             i2 = (int) (((v2 - vmn2)/(vmx2-vmn2))*1000.) ;
             i3 = (int) (((v3 - vmn3)/(vmx3-vmn3))*1000.) ;
             i4 = (int) (((v4 - vmn4)/(vmx4-vmn4))*1000.) ;
             i5 = (int) (((v5 - vmn5)/(vmx5-vmn5))*1000.) ;
             i6 = (int) (((v6 - vmn6)/(vmx6-vmn6))*1000.) ;
 
             rt.s1.setValue(i1) ;
             rt.s2.setValue(i2) ;
             rt.s3.setValue(i3) ;
             rt.s4.setValue(i4) ;
             rt.s5.setValue(i5) ;
             rt.s6.setValue(i6) ;

             cg = 0.0 ;
             cp = 0.0 ;

             npt = 0 ;

                 ifuel = 1 ;
                 ides = 1;
                 weight = wtd / fconv ;
                 loadOut() ;
                 irange = 1 ;
                 ides = 1;
                 ifuel =1 ;

             solve.getAtmos() ;

             solve.comPute() ;

           }  // end handle
         }  //  end  left
       }   // end ballistic shell

  } // end of Act

  class View extends Canvas  
         implements Runnable{
     Drop outerparent ;
     Thread runner ;
     Point locate,anchor;
   
     View (Drop target) {
         setBackground(Color.white) ;
         runner = null ;
     } 

     public Insets insets() {
        return new Insets(0,5,0,5) ;
     }
 
     public boolean mouseDown(Event evt, int x, int y) {
        anchor = new Point(x,y) ;
        return true;
     }

     public boolean mouseUp(Event evt, int x, int y) {
        handleb(x,y) ;
        return true;
     }

     public boolean mouseDrag(Event evt, int x, int y) {
        handle(x,y) ;
        return true;
     }

     public void handle(int x, int y) {  // slider widgets
       // determine location
       if (y >= 20 && y <= 375) {
         if (x <= 35 ) {   // zoom widget
           if (y >= 45 && y <= 375) {
             sldloc = y ;
             if (sldloc < 50) sldloc = 50;
             if (sldloc > 350) sldloc = 350;
             fact = facmin + (350 - sldloc) * facrat;
             if (viewflg == 0) {
               if (fact < 5.0) fact = 5.0 ;
             }
           }
         }
         if (x >= 36 ) {   // translate
           locate = new Point(x,y) ;
           yt =  yt + (int) (.2*(locate.y - anchor.y)) ;
           xt =  xt + (int) (.4*(locate.x - anchor.x))  ;
           if (xt > 50000) xt = 50000 ;
           if (xt < -50000) xt = -50000 ;
           if (yt > 50000) yt = 50000 ;
           if (yt <-50000) yt = -50000 ;
         }
       }
       if (viewflg == 2) {
         factc = fact ;
         xtc = xt ;
         ytc = yt ;
         sldc = sldloc ;
       }
       if (viewflg == 1) {
         facts = fact ;
         xts = xt ;
         yts = yt ;
         slds = sldloc ;
       }
       if (viewflg == 0) {
         facto = fact ;
         xto = xt ;
         yto = yt ;
         sldo = sldloc ;
       }
     }

     public void handleb(int x, int y) { // view buttons
       float fl3 ;
       int i,j,i3 ;

       if (x <= 30) { 
          if (y >=31 && y <= 45) {  // grid switch
             gridon = -gridon ;
          }
       }
 
       if (y > 465) {
          if (x >= 100 && x <= 150) { // pad switch 
//             if (viewflg == 0) setDesignView() ;
//             if (viewflg == 1) setRangeView() ;
             if (viewflg == 2) setGraphView() ;
          }
          if (x >= 200 && x <= 250) { // trak switch  
             trakon = -trakon ;
          }
       }

       if (y >= 475) {
          if (viewflg == 1) {
             if (x <= 40) { // save plot
                npts[nsav] = npt ;
                nsav = nsav + 1 ;
                if (nsav == 5) nsav = 4 ;
 
                for (i=0; i<=npts[nsav]; ++i){
                   posx[nsav][i] = 0.0 ;
                   posy[nsav][i] = 0.0 ;
                   posa[i] = pid2 ;
                   posb1 = 0.0 ;
                }
                npts[nsav] = 0 ;
            }
            if (x >= 350) { // clear plots
                nsav = 0 ;
                for (j=0; j<=4; ++j) {
                  for (i=0; i<=npts[j]; ++i){
                     posx[j][i] = 0.0 ;
                     posy[j][i] = 0.0 ;
                     posa[i] = pid2 ;
                     posb1 = 0.0 ;
                  }
                  npts[j] = 0 ;
                }
             }
          }
       }

       if (y < 25) {
          if (viewflg == 0 && lnchgrf == 0) {
             if (x >=35 && x <= 95) {  // nose design
               part = 1 ;
             }
             if (x >=100 && x <= 160) {  // payload design
               part = 2 ;
             }
             if (x >=165 && x <= 225) {  // body design
               part = 3 ;
               if (rktype < 2 || rktype > 2){
               }
               if (rktype == 2){
               }
             }
             if (x >=230 && x <= 295) {  // fins design
               part = 4 ;
             }
             ides = 0 ;
          }
       }
       view.repaint() ;
     }

     public void start() {
        if (runner == null) {
           runner = new Thread(this) ;
           runner.start() ;
        }
     }

     public void run() {
       int timer,i ;
       double vvld,hvld,angle,deltmx,oldmass,newmass;
       double vald,hald;
       String outht,outspd,outfor,outpres,outtemp ;
   
       timer = 100 ;
       deltim  = .2 ;
       angle = pid2 ;
       oldmass = volbot * .00237 /1728. ;
       while (true) {
          try { Thread.sleep(timer); }
          catch (InterruptedException e) {}
          outht = " ft" ;
          if (lunits == 1) outht = " m" ;
          outspd = " fps" ;
          if (lunits == 1) outspd = " mps" ;
          outfor = " oz" ;
          if (lunits == 1) outfor = " g" ;
          outpres = " psi" ;
          if (lunits == 1) outpres = " kPa" ;
          outtemp = " F" ;
          if (lunits == 1) outtemp = " C" ;

          posa[0] = (90.0 - lnchang) * convdr ;
          if (fire == 1) {  // launch sequence
             if (comp == 1 && istab >= 1 && 
               irange == 1 && ifuel == 1 && ides == 1) {
               fltim = fltim + deltim ;
               if (planet == 2) wind = 0.0 ;  // no wind on the moon
      // countdown
               if (fltim < 0.0) {
                  act.lnch.o1.setText(String.valueOf(filter0(fltim))) ;
               }
      // flight
               if (fltim >= 0.0) {
                  act.lnch.o1.setForeground(Color.green) ;
                  act.lnch.bt5.setBackground(Color.green) ;
                  act.lnch.bt5.setForeground(Color.black) ;
      // thrust
                  if (rktype == 10) {  // ballistic-no thrust or recovery
                      rtype = 0 ;
                      wtflt = weight * wtrat ;
                      thrust = 0.0 ;
                      deltim = .05 ;
                  }
                  if (rktype == 1) {  // stomp rocket-no thrust or recovery
                      rtype = 0 ;
                      wtflt = weight * wtrat ;
                      thrust = 0.0 ;
                      deltim = .05 ;
                  }
                  if (rktype == 2) {  // bottle rocket-thrust or recovery
                      if (vloc <= llaunch &&
                            fltim <= (timrail + .15) 
                           ) { // launch tube-constant weight-constant vol
                         wtflt = weight * wtrat ;
                         thrust = (fpres - ps0)  * noza * 16.0 ;
                         instwat = wat ;
                         instair = volair ;
                         instpres = fpres ;
                         deltim = .01 ;
                         tim2 = fltim ;
                         oldmass = instair * .00237 /1728. ;
                      }
                      if (vloc >= llaunch && 
                                   instwat >= 0.01 && 
                                   instpres >= ps0) { // water expulsion
                         deltim = .01 ;
                         volrat = volair / instair ;
                         instpres = fpres * Math.pow(volrat,1.4) ;
                                // 1.94 slug/cu ft = density water
                         if (instpres >= ps0) {
                           uexit = Math.sqrt(2.0 * (instpres - ps0) * 144 / 1.94) ; // ft/sec
                         }
                         if (instpres <= ps0) {
                           uexit = 0.0 ;
                         }
                         mdot = 1.94 * uexit * noza / 144. ;  //   slug/sec
                         thrust = mdot * uexit * 16.0 ;  //  oz
                         instwat = instwat - mdot * deltim * 1728. / 1.94 ;  // cu in
                         instair = volbot - instwat ;
                         oldmass = instair * .00237 /1728. ;
                         wtflt = (weight - wfuel + instwat * .578) * wtrat ; // oz
                         tim2 = fltim ;
                      }
                      if (instwat <= 0.0 ) instwat = 0.0 ;
                      if (vloc >= llaunch && 
                                   instwat <=  0.05 &&
                                   instpres <= ps0 ) {  // out of fuel-thrust =  0
                         wtflt = (weight - wfuel) * wtrat ;
                         thrust = 0.0 ;
                         deltim = .2 ;
                      }
                      if (vloc >= llaunch && 
                                   instwat <= 0.0 && 
                                   instpres >= ps0) { //out of fuel .. pressure pop 
                         wtflt = (weight - wfuel) * wtrat ;
                         uexit = Math.sqrt(1.4 * rgas * ts0) ;
                         mdot = .34346 * noza * (instpres/14.7) / 32.2 ;
                         newmass = oldmass - mdot * deltim ;
                         if (newmass >= 0.0 ) {
                             thrust = mdot * uexit * 16.0 
                                  + (instpres - ps0) * noza * 16.0 ; 
                             instpres = instpres * Math.pow(newmass/oldmass,1.4) ;
                             oldmass = newmass ;
                         }
                         if (newmass < 0.0) {
                             thrust = 0.0 ;
                             instpres = 0.0 ;
                         }
                         if (instpres <= ps0) instpres = ps0 -.05 ;
                      }
                      if (instpres <= ps0) { 
                         wtflt = (weight - wfuel) * wtrat ;
                         thrust = 0.0 ;
                         deltim = .2 ;
                      }
                  }
                  if (rktype == 3) {  // model rocket - thrust and recovery system
                      if (nstage == 1) {
                         wtflt = (weight - (fltim/tim2)*wfuel) * wtrat ;
                         if (fltim > tim2) wtflt = (weight - wfuel) * wtrat ;
                         if(fltim <= tim1) {
                            thrust = 16.0*th1 ;
                            deltim = tim1 / 10.0 ;
                         }
                      }
                      if (nstage == 2) {
                         if (fltim < tim1) deltim = tim1 / 30.0 ;
                         if (fltim < tim2b1) {
                           wtflt = (weight - (fltim/tim2b1)*wfuelb1) * wtrat ;
                           if(fltim <= tim1b1) thrust = 16.0*th1b1 ;
                           if(fltim >= tim1b1) thrust = 16.0*th2b1 ; 
                         }
                         if ((fltim >= tim2b1) && (fltim < tim2)) {
                           wtflt = (weight - wfuelb1 - wengb1 - 
                              ((fltim - tim2b1)/(tim2 - tim2b1))*wfuel) * wtrat ;
                           thrust = 16.0*th1 ;
                         }
                         if (fltim > tim2) {
                           wtflt = (weight - wfuelb1 - wengb1 -wfuel) * wtrat ;
                         }
                      }
                      if((fltim >= tim1) && (fltim < tim2)) {
                          thrust = 16.0*th2 ;
                      }
                      if((fltim >= tim2) && (fltim < timd)) {
                          thrust = 0.0 ;
                          deltim = .2 ;
                      }
                  }
                  vvld = vvel ;
                  hvld = hvel ;
                  vald = vacc ;
                  hald = hacc ;
        // powered  and coasting
                  if (fltim < timd || rtype == 0 || planet == 1 || planet == 2) {
                     angle = Math.atan2(vvel,hvel) ;
                     if (vloc < llaunch && fltim < timd) {
                        angle = (90.0 - lnchang) * convdr ;
                     }
                     if (cockflg == 1 && cockcal == 1) {
                        angle = pid2 + Math.atan2(wind-hvel,vvel) ;
                     }

                     vacc = ((thrust-drag)*Math.sin(angle)-wtflt)/(wtflt/(g0 * wtrat)) ;
                     hacc = (thrust-drag)*Math.cos(angle) / (wtflt/(g0 * wtrat))  ;
                     vvel = vvld + .5 * (vacc + vald) * deltim ;
                     hvel = hvld + .5 * (hacc + hald) * deltim ;
                     spd = Math.sqrt(vvel*vvel + hvel*hvel) ;
                     drag = (16.0 * cd * .5 * rho * catot * spd * spd / 144.) ; 
                  }

        // recovery
                  if (fltim >= timd && rtype >= 1 && (planet == 0 || planet == 3)) {
                     vvel = -Math.sqrt((2.0 * wtflt * 144.)/
                                       (16.0 * cdrec * rho * carec));
                     spd = -vvel ;
                     angle = -pid2 ;
                     hvel = -hvld ;
                     deltmx = 1.0 ;
                     if (vmax > 500.) deltmx = 2.0 ;
                     if (vmax > 700.) deltmx = 3.0 ;
                     if (vmax > 1000.) deltmx = 5.0 ;
                     deltim = deltim + .2 ;
                     if (deltim > deltmx) deltim = deltmx ;
                     drag = wtflt ;
                  }

                  vloc = vloc + .5 * (vvel + vvld) * deltim ;
                  hloc = hloc + .5 * (hvel + hvld) * deltim ;
                  if (drgmode == 0) solve.getAtmos() ;

                  npt = npt + 1 ;
          // determine if on or off rail ..
                  posx[nsav][npt] = hloc + wind * (fltim - timrail) ;
                  if (vloc < llaunch && fltim < tim1) {
                     timrail = fltim ;
                     posx[nsav][npt] = hloc ;
                  }
                  posy[nsav][npt] = vloc ;
                  posa[npt] = angle ;

          // determine if engine burning        
                  if (rktype == 3 || rktype == 2) {    
                    if (fltim <= tim2) nburn = npt ;
          // discarded 1st stage
                    if (nstage == 2) {
                      if (fltim <= tim2b1) posb1 = posy[nsav][npt] ;
                      if (fltim > tim2b1) posb1 = vloc - 100.0 * (fltim - tim2b1) ;
                    }
                  }

                  cockcal = 0 ;
                  if (fltim > timrail && fltim < tim2) cockcal = 1;
         // deploy parachute for bottle rocket at apogee
                  if (rktype == 2 && rtype >= 1 && fltim < timd) {
                     if (vvel < 0.0) timd = fltim ;
                  }

                  act.lnch.o1.setText(String.valueOf(filter3(fltim))) ;
               }
     // update maximums
               act.lnch.o2.setText(String.valueOf(filter0(vloc*lconv1))+outht) ;
               act.lnch.o3.setText(String.valueOf(filter0(spd*lconv1))+outspd) ;
               act.lnch.o4.setText(String.valueOf(filter0(posx[nsav][npt] * lconv1))+outht);
               if (vloc > vmax) {
                  vmax = vloc ;
                  act.lnch.o5.setText(String.valueOf(filter0(vmax*lconv1))+outht) ;
               }
               if (Math.abs(posx[nsav][npt]) > Math.abs(hmax)) {
                  hmax = posx[nsav][npt] ;
                  act.lnch.o7.setText(String.valueOf(filter0(hmax*lconv1))+outht) ;
               }
               if (spd > spdmax) {
                  spdmax = spd;
                  act.lnch.o6.setText(String.valueOf(filter0(spdmax*lconv1))+outspd) ;
               }
     // shutdown .. hit the ground
               if (vloc < 0.0 ) {  
                  posa[npt] = 0.0 ;
                  comp = 0 ;
                  vloc = 0.0 ;
                  act.lnch.o2.setText(String.valueOf(filter0(vloc*lconv1))+outht) ;
                  irange = 0 ;
 //                 ifuel = 0 ;
                  act.lnch.bt5.setBackground(Color.red) ;
                  act.lnch.bt5.setForeground(Color.white) ;
               }
             }
             act.lnch.o9.setText(String.valueOf(filter3(drag*fconv)) + outfor) ;
             act.lnch.o10.setText(String.valueOf(filter3(wtflt*fconv)) + outfor) ;
             act.lnch.o11.setText(String.valueOf(filter1(ps0 * pconv)) + outpres) ;
             act.lnch.o12.setText(String.valueOf(filter0(ts0 * tconv - tcon0)) + outtemp ) ;
 
     // strip charts
             posx[6][npt] = 10.0*fltim ;
             posy[6][npt] = wtflt ;
             posx[7][npt] = 10.0*fltim ;
             posy[7][npt] = drag ;
             posx[8][npt] = 10.0*fltim ;
             posy[8][npt] = Math.abs(vvel) ;
             posx[9][npt] = 10.0*fltim ;
             posy[9][npt] = vloc ;

             if (stepon == 1) {
                comp = 0 ;
                if (step == 1) {
                  comp = 1;
                  step = 0 ;
                } 
             }
             if (trakon > 0 && viewflg == 2) {  // tracking view for strip charts
                 if (fact*(10.0*fltim) > 250.0) {
                    xt = 250 - (int) (fact*(10.0 * fltim)) ;
                }
             }
          }
     // reset integration
          if (fire == 0) {
             wtflt = weight * wtrat ;
             thrust = 0.0 ;
             timrail = 0.0 ;
             deltim = .2 ;
             fltim = 0.0 ;
             hloc = 0.0 ;
             vloc = vloc0 ;
             vvel = 0.0 ;
             hvel = 0.0 ;
             vmax = 0.0 ;
             hmax = 0.0 ;
             spdmax = 0.0 ;
             npt = 0 ;
             nburn = 0 ;
             ps0 = 14.7 ;
             ts0 = 518. ;
             if (drgmode <= 1) solve.getAtmos() ;           
  
             act.lnch.o1.setText(String.valueOf(filter0(fltim))) ;
             act.lnch.o2.setText(String.valueOf(filter0(vloc*lconv1))+outht) ;
             act.lnch.o3.setText(String.valueOf(filter0(vvel*lconv1))+outspd) ;
             act.lnch.o4.setText(String.valueOf(filter0(hloc*lconv1))+outht) ;
             act.lnch.o5.setText(String.valueOf(filter0(vmax*lconv1))+outht) ;
             act.lnch.o6.setText(String.valueOf(filter0(spdmax*lconv1))+outspd) ;
             act.lnch.o7.setText(String.valueOf(filter0(hmax*lconv1))+outht) ;
             act.lnch.o9.setText(String.valueOf(filter3(drag*fconv)) + outfor) ;
             act.lnch.o10.setText(String.valueOf(filter3(wtflt*fconv)) + outfor) ; 
             act.lnch.o11.setText(String.valueOf(filter1(ps0 * pconv)) + outpres) ;
             act.lnch.o12.setText(String.valueOf(filter0(ts0 * tconv - tcon0)) + outtemp ) ;
          }
          if (trakon > 0 && viewflg == 1) {  // tracking view
             fact = 2.5 ;
             if (planet == 2) fact = .06 ;
             if (planet == 3) fact = .11 ;
             xt = 190 - (int)(fact * posx[nsav][npt]) ;
             yt = 310 + (int)(fact * posy[nsav][npt]) ;
          }
          view.repaint() ;
 
       }
     }

     public void update(Graphics g) {
           view.paint(g) ;
     }
 
     public void paint(Graphics g) {
        int i,j,k,n ;
        int nump ;
        int exes[] = new int[9] ;
        int whys[] = new int[9] ;
        int ylabel,ylabel2,xlabel,xlabel2;
        double yval,xval,scale,btbase;
        double cpa,spa,nosx,nosy,hstg,pumph;
        double factm ;
        String words,outlng ;
        Color col1,col2 ;

        col1 = new Color(0,121,0) ;   // dark green
        col2 = new Color(254,121,0) ; // dark orange
 
 // design view
        if (viewflg == 0) {
           offsGg.setColor(Color.white) ;
           offsGg.fillRect(0,0,600,600) ;
           if (gridon >= 0) {       // Grid paper background
             if (lunits == 0) {
                for (j=0; j<=60; ++j) {
                  offsGg.setColor(Color.cyan) ;
                  if ((j/12) * 12 == j) offsGg.setColor(Color.blue) ;
                  whys[0] = 0 ; whys[1] = 500 ;
                  exes[0] = exes[1] = (int) (fact*(j)) + xt  ;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                  exes[0] = exes[1] = (int) (-fact*(j)) + xt  ;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                }
                for (j=0; j<=60; ++j) {
                  offsGg.setColor(Color.cyan) ;
                  if ((j/12) * 12 == j) offsGg.setColor(Color.blue) ;
                  exes[0] = 0 ; 
                  exes[1] = 500 ;
                  whys[0] = whys[1] = (int) (fact*(j)) + yt;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                  whys[0] = whys[1] = (int) (-fact*(j)) + yt;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                  if (j == 1) {
                     whys[0] = (int) (-fact*(j)) + yt;
                     offsGg.setColor(Color.black) ;
                     offsGg.drawString("1 inch",230,whys[0]+5) ; 
                  }
                  if (j == 12) {
                     whys[0] = (int) (-fact*(j)) + yt;
                     offsGg.setColor(Color.blue) ;
                     offsGg.drawString("1 foot",230,whys[0]+5) ; 
                  }
                }
             }
             if (lunits == 1) {
                for (j=0; j<=60; ++j) {
                  offsGg.setColor(Color.cyan) ;
                  if ((j/12) * 12 == j) offsGg.setColor(Color.blue) ;
                  whys[0] = 0 ; whys[1] = 500 ;
                  exes[0] = exes[1] = (int) (fact*(j* 10.0 / lconv2)) + xt  ;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                  exes[0] = exes[1] = (int) (-fact*(j* 10.0 / lconv2)) + xt  ;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                }
                for (j=0; j<=60; ++j) {
                  offsGg.setColor(Color.cyan) ;
                  if ((j/10) * 10 == j) offsGg.setColor(Color.blue) ;
                  exes[0] = 0 ; 
                  exes[1] = 500 ;
                  whys[0] = whys[1] = (int) (fact*(j *10.0 / lconv2)) + yt;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                  whys[0] = whys[1] = (int) (-fact*(j * 10.0 / lconv2)) + yt;
                  offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
                  if (j == 1) {
                     whys[0] = (int) (-fact*(j* 10.0 / lconv2)) + yt;
                     offsGg.setColor(Color.black) ;
                     offsGg.drawString("10 cm",230,whys[0]+5) ; 
                  }
                  if (j == 10) {
                     whys[0] = (int) (-fact*(j* 10.0 / lconv2)) + yt;
                     offsGg.setColor(Color.blue) ;
                     offsGg.drawString("1 meter",230,whys[0]+5) ; 
                  }
                }
             }
           }
        }

        if (viewflg == 2) {   // data traces
           offsGg.setColor(Color.white) ;
           offsGg.fillRect(0,0,600,600) ;
           if (gridon >= 0) {       // Grid paper background
             for (j=0; j<=500; ++j) {
               offsGg.setColor(Color.cyan) ;
               exes[0] = 0 ; 
               exes[1] = 500 ;
//               whys[0] = whys[1] = (int) (fact*(10.*j)) + yt;
               whys[0] = whys[1] = (int) (fact*(10.*j));
               offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
//               whys[0] = whys[1] = (int) (-fact*(10.*j)) + yt;
               whys[0] = whys[1] = (int) (-fact*(10.*j));
               offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
             }
             for (j=0; j<=600; ++j) {
               offsGg.setColor(Color.cyan) ;
               whys[0] = 0 ; whys[1] = 500 ;
//               exes[0] = exes[1] = (int) (fact*(10.0*j)) + xt  ;
               exes[0] = exes[1] = (int) (fact*(10.0*j))  ;
               offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
//               exes[0] = exes[1] = (int) (-fact*(10.0*j)) + xt  ;
               exes[0] = exes[1] = (int) (-fact*(10.0*j)) ;
               offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
             }
          }
          for (i=6; i<= 9; ++ i) {
            exes[0] = (int) (fact*(0.0)) + xt ;
            whys[0] = (int) (fact*((i-6) * 100.0 - posy[i][0])) + yt ;
            xlabel = 50 ;
            scale = 1.0 ;
/*
            if (i == 5) {
               offsGg.setColor(Color.black) ;
               offsGg.drawString("Thrust",exes[0]-50,whys[0]) ;
            }
*/
            if (i == 6) {
               offsGg.setColor(Color.black) ;
               ylabel = (int) (fact*((i-6) * 100.0)) + yt ;
               if (wtd > 0.0) {
                 scale = 100.0 /wtd ;
                 whys[0] = (int) (fact*((i-5) * 100.0 - scale * posy[i][0])) + yt ;
               }
               ylabel = (int) (fact*((i-6) * 100.0)) + yt ;
               offsGg.drawString("Weight",xlabel,ylabel) ;
            }
            if (i == 7) {
               offsGg.setColor(Color.red) ;
               if (wtd > 0.0) {
                 scale = 100.0 /wtd ;
                 whys[0] = (int) (fact*((i-6) * 100.0 - scale * posy[i][0])) + yt ;
               }
               ylabel = (int) (fact*((i-6) * 100.0)) + yt ;
               offsGg.drawString("Drag",xlabel,ylabel) ;
            }
            if (i == 8) {
               offsGg.setColor(Color.magenta) ;
               if (spdmax > 0.0) {
                 scale = 100.0 /spdmax ;
                 whys[0] = (int) (fact*((i-6) * 100.0 - scale * posy[i][0])) + yt ;
               }
               ylabel = (int) (fact*((i-6) * 100.0)) + yt ;
               offsGg.drawString("Speed",xlabel,ylabel) ;
            }
            if (i == 9) {
               offsGg.setColor(Color.blue) ;
               if (vmax > 0.0) {
                 scale = 100.0 / vmax ;
                 whys[0] = (int) (fact*((i-6) * 100.0 - scale * posy[i][0])) + yt ;
               }
               ylabel = (int) (fact*((i-6) * 100.0)) + yt ;
               offsGg.drawString("Height",xlabel,ylabel) ;
            }
            for (j=1; j<=npt; ++j){
              exes[1] = exes[0] ;
              whys[1] = whys[0] ;
              exes[0] = (int) (fact*(posx[i][j])) + xt ;
              whys[0] = (int) (fact*((i-6) * 100.0 - scale * posy[i][j])) + yt ;
              if (i==6) whys[0] = (int) (fact*((i-5) * 100.0 - scale * posy[i][j])) + yt ; 
              offsGg.drawLine(exes[0],whys[0],exes[1],whys[1]) ;
            }
          }
          offsGg.setColor(Color.black) ;
          xlabel = 200 ;
          whys[0] = (int) (fact*(320.0)) + yt ;
          offsGg.drawString("Time",xlabel,whys[0]) ;
        }
 // border 
 // right 
        offsGg.setColor(Color.lightGray) ;
        offsGg.fillRect(364,0,30,500) ;
 
 // left side zoom widget
        offsGg.setColor(Color.lightGray) ;
        offsGg.fillRect(0,0,35,500) ;
        offsGg.setColor(Color.black) ;
        offsGg.drawString("Zoom",2,365) ;
        offsGg.drawLine(15,50,15,350) ;
        offsGg.fillRect(5,sldloc,20,5) ;

        if (gridon < 0) {     // Grid button
           offsGg.setColor(Color.blue) ;
           offsGg.fillRect(0,30,30,15) ;
           offsGg.setColor(Color.white) ;
           offsGg.drawString("Grid",2,42) ;
        }
        if (gridon >= 0) {
           offsGg.setColor(Color.yellow) ;
           offsGg.fillRect(0,30,30,15) ;
           offsGg.setColor(Color.black) ;
           offsGg.drawString("Grid",2,42) ;
        }
 // bottom
        offsGg.setColor(Color.lightGray) ;
        offsGg.fillRect(34,465,490,40) ;
        offsGg.setColor(Color.blue) ;
        offsGg.fillRect(100,470,40,20) ;
        offsGg.setColor(Color.white) ;
        offsGg.drawString("Find",108,485) ;
        if (trakon < 0) {  // Track button
           offsGg.setColor(Color.blue) ;
           offsGg.fillRect(200,470,40,20) ;
           offsGg.setColor(Color.white) ;
           offsGg.drawString("Track",205,485) ;
        }
        if (trakon >= 0) {
           offsGg.setColor(Color.yellow) ;
           offsGg.fillRect(200,470,40,20) ;
           offsGg.setColor(Color.black) ;
           offsGg.drawString("Track",205,485) ;
        }
        if (viewflg == 1) {
           offsGg.setColor(Color.blue) ;
           offsGg.fillRect(0,470,40,20) ;
           offsGg.setColor(Color.white) ;
           offsGg.drawString("Save",2,485) ;
           offsGg.setColor(Color.blue) ;
           offsGg.fillRect(350,470,40,20) ;
           offsGg.setColor(Color.white) ;
           offsGg.drawString("Clear",352,485) ;
        }
 // top
        offsGg.setColor(Color.lightGray) ;
        offsGg.fillRect(34,0,390,25) ;
        if (viewflg == 0) {
           if (lnchgrf == 0) {
             offsGg.setColor(Color.blue) ;
             offsGg.fillRect(35,2,60,20) ;
             offsGg.setColor(Color.white) ;
             offsGg.drawString("Nose",45,15) ;

             offsGg.setColor(Color.blue) ;
             offsGg.fillRect(100,2,60,20) ;
             offsGg.setColor(Color.white) ;
             offsGg.drawString("Payload",105,15) ;

             offsGg.setColor(Color.blue) ;
             offsGg.fillRect(165,2,60,20) ;
             offsGg.setColor(Color.white) ;
             offsGg.drawString("Body",175,15) ;

             offsGg.setColor(Color.blue) ;
             offsGg.fillRect(230,2,60,20) ;
             offsGg.setColor(Color.white) ;
             offsGg.drawString("Fins",240,15) ;

             if (part == 1) {
                offsGg.setColor(Color.yellow) ;
                offsGg.fillRect(35,2,60,20) ;
                offsGg.setColor(Color.black) ;
                offsGg.drawString("Nose",45,15) ;
             }

             if (part == 2) {
                offsGg.setColor(Color.yellow) ;
                offsGg.fillRect(100,2,60,20) ;
                offsGg.setColor(Color.black) ;
                offsGg.drawString("Payload",105,15) ;
             }

             if (part == 3) {
                offsGg.setColor(Color.yellow) ;
                offsGg.fillRect(165,2,60,20) ;
                offsGg.setColor(Color.black) ;
                offsGg.drawString("Body",175,15) ;
             }

             if (part == 4) {
                offsGg.setColor(Color.yellow) ;
                offsGg.fillRect(230,2,60,20) ;
                offsGg.setColor(Color.black) ;
                offsGg.drawString("Fins",240,15) ;
             }
           }
        }
        if (viewflg == 1) {
               // time-height boxes
           offsGg.setColor(Color.black) ;
           offsGg.drawString("Time",50,15) ;
           offsGg.drawString("Height",170,15) ;
           offsGg.fillRect(90,2,50,20) ;
           offsGg.fillRect(220,2,70,20) ;
           if (fltim <= 0.0) {
             offsGg.setColor(Color.green) ;
             offsGg.drawString(String.valueOf(filter0(fltim)),100,15) ;
           }
           if (fltim > 0.0) {
             offsGg.setColor(Color.yellow) ;
             offsGg.drawString(String.valueOf(filter1(fltim)),100,15) ;
           }
           offsGg.setColor(Color.yellow) ;
           offsGg.drawString(String.valueOf(filter0(vmax*lconv1)),225,15) ;
        }
        g.drawImage(offImg,0,0,this) ;   

     }  // end Paint
  }  // End View

} // end DropSim
