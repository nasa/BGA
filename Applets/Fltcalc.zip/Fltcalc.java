/*  
                Fltcalc

               Version 1.0

       Calculator Applet to determine the max height and time
     for a ballistic projectile and a coasting rocket with drag
    Input:  weight, drag coefficient, area, air density, initial velocity
    Output:  max height, time of max height
*/

import java.awt.*;
import java.lang.Math ;

public class Fltcalc extends java.applet.Applet {

   static double convdr = 3.1415926/180. ;
   double weight, cd, area, alt, termv ;
   double rho, ps0, ts0, g0, wtrat ;
   double v0, ymax,tmax ;
   int lunits, planet;
   int dmode,wmode,fmode;

   In in ;

   public void init() {

     setLayout(new GridLayout(1,1,0,0)) ;

     setDefaults () ;

     in = new In(this) ;

     add(in) ;

     computeFlt() ;
  }
 
  public void setDefaults() {
  
     dmode = 1 ;
     lunits = 0;
     planet = 0 ;
     wmode = 0 ;
     fmode = 0 ;

     v0 = 100. ;
     wtrat = 1.0 ;
     weight = 10. ;
     area = .1 ;
     rho = .00237 ;
     alt = 0.0 ;
     cd = .7 ;
     g0 = 32.2 ;
     tmax = 3.1 ;
     ymax = 155.28 ;
 
  }

     public void getFreeStream() {    //  free stream conditions
       double hite,pvap,rgas,gama ;       /* MODS  19 Jan 00  whole routine*/

       rgas = 1718. ;                /* ft2/sec2 R */
       gama = 1.4 ;
       hite = alt ;
       if (planet == 0) {    // Earth  standard day
         if (hite <= 36152.) {           // Troposphere
            ts0 = 518.6 - 3.56 * hite/1000. ;
            ps0 = 2116. * Math.pow(ts0/518.6,5.256) ;
         }
         if (hite >= 36152. && hite <= 82345.) {   // Stratosphere
            ts0 = 389.98 ;
            ps0 = 2116. * .2236 *
                 Math.exp((36000.-hite)/(53.35*389.98)) ;
         }
         if (hite >= 82345.) {
            ts0 = 389.98 + 1.645 * (hite-82345)/1000. ;
            ps0 = 2116. *.02456 * Math.pow(ts0/389.98,-11.388) ;
         }
         rho = ps0/(rgas * ts0) ;
       }

       if (planet == 1) {   // Mars - curve fit of orbiter data
         rgas = 1149. ;                /* ft2/sec2 R */
         gama = 1.29 ;

         if (hite <= 22960.) {
            ts0 = 434.02 - .548 * hite/1000. ;
            ps0 = 14.62 * Math.pow(2.71828,-.00003 * hite) ;
         }
         if (hite > 22960.) {
            ts0 = 449.36 - 1.217 * hite/1000. ;
            ps0 = 14.62 * Math.pow(2.71828,-.00003 * hite) ;
         }
         rho = ps0/(rgas*ts0) ;
       }
 
       return ;
     }

  public void computeFlt() {
 
              // compute  
     if (fmode == 0) {  // ballistic
        in.dn.out1.setText("Not Needed") ;
        ymax = v0 * v0 / (2.0 * g0) ;
        tmax = v0 / g0 ;
        if (lunits == 0) {
           in.dn.out2.setText(String.valueOf(filter3(ymax))) ;
           in.dn.out3.setText(String.valueOf(filter3(tmax))) ;
        }
        if (lunits == 1) {
           in.dn.out2.setText(String.valueOf(filter3(ymax * .3048))) ;
           in.dn.out3.setText(String.valueOf(filter3(tmax))) ;
        }
     }
     if (fmode == 1) {  // include drag
        termv = Math.sqrt( 2.0 * wtrat * weight / (cd * rho * area)) ;
        tmax = (termv / g0) * Math.atan(v0 / termv) ;
        ymax = (termv * termv / (2.0 * g0) ) * Math.log((v0*v0 + termv*termv)/(termv*termv)) ;

        if (lunits == 0) {
           in.dn.out1.setText(String.valueOf(filter3(termv))) ;
           in.dn.out2.setText(String.valueOf(filter3(ymax))) ;
           in.dn.out3.setText(String.valueOf(filter3(tmax))) ;
        }
        if (lunits == 1) {
           in.dn.out1.setText(String.valueOf(filter3(termv * .3048))) ;
           in.dn.out2.setText(String.valueOf(filter3(ymax * .3048))) ;
           in.dn.out3.setText(String.valueOf(filter3(tmax))) ;
        }
     }
  }
 
  public int filter0(double inumbr) {
     //  integer output
       float number ;
       int intermed ;

       intermed = (int) (inumbr) ;
       number = (float) (intermed);
       return intermed ;
  }
 
  public float filter3(double inumbr) {
     //  output only to .001
       float number ;
       int intermed ;
  
       intermed = (int) (inumbr * 1000.) ;
       number = (float) (intermed / 1000. );
       return number ;
  }

  public float filter5(double inumbr) {
     //  output only to .00001
       float number ;
       int intermed ;
  
       intermed = (int) (inumbr * 100000.) ;
       number = (float) (intermed / 100000. );
       return number ;
  }

  public float filter7(double inumbr) {
     //  output only to .0000001
       float number ;
       int intermed ;
  
       intermed = (int) (inumbr * 10000000.) ;
       number = (float) (intermed / 10000000. );
       return number ;
  }

  class In extends Panel {
     Fltcalc outerparent ;
     Titl titl ;
     Up up ;
     Dn dn ;

     In (Fltcalc target) {                           
        outerparent = target ;
        setLayout(new GridLayout(3,1,5,5)) ;

        titl = new Titl(outerparent) ;
        up = new Up(outerparent) ;
        dn = new Dn(outerparent) ;

        add(titl) ;
        add(up) ;
        add(dn) ;
     }

     class Titl extends Panel {
        Label la,lc,ld,le ;

        Titl (Fltcalc target) {                           
            outerparent = target ;
            setLayout(new GridLayout(4,1,0,0)) ;

            lc = new Label("Ballistic Flight Calculator", Label.CENTER) ;

            ld = new Label("Select planet, mode, and units", Label.CENTER) ;
            ld.setForeground(Color.red) ;

            la = new Label("If drag inlcuded, enter weight or mass, ", Label.CENTER) ;
            la.setForeground(Color.blue) ;

            le = new Label("area, drag coefficient, altitude or air density", Label.CENTER) ;
            le.setForeground(Color.blue) ;

            add(lc) ;
            add(ld) ;
            add(la) ;
            add(le) ;
        }
     }

     class Up extends Panel {
        TextField o1,o2,o3,o4,o5 ;
        Label l1,l2,l4,l5;
        Label l1u,l2u,l3u,l4u,l5u;
        Choice untch,dmodch, plntch, wmodch, fltmodch;

        Up (Fltcalc target) {                           
            outerparent = target ;
            setLayout(new GridLayout(6,3,5,5)) ;

            l1u = new Label(" lbs ", Label.LEFT) ;
            l4 = new Label("Cross Section Area", Label.RIGHT) ;
            l4u = new Label(" sq in ", Label.LEFT) ;
            l2 = new Label("Drag Coefficient", Label.RIGHT) ;
            l2u = new Label("  ", Label.LEFT) ;
            l3u = new Label(" ft ", Label.LEFT) ;
   
            l5 = new Label("Initial Velocity", Label.RIGHT) ;
            l5u = new Label(" ft/sec ", Label.LEFT) ;

            o1 = new TextField("10.0",5) ;
            o1.setBackground(Color.white) ;
            o1.setForeground(Color.black) ;
            o2 = new TextField("0.7",5) ;
            o2.setBackground(Color.white) ;
            o2.setForeground(Color.black) ;
            o3 = new TextField("0.0",5) ;
            o3.setBackground(Color.white) ;
            o3.setForeground(Color.black) ;
            o4 = new TextField("14.4",5) ;
            o4.setBackground(Color.white) ;
            o4.setForeground(Color.black) ;
            o5 = new TextField("100.0",5) ;
            o5.setBackground(Color.white) ;
            o5.setForeground(Color.black) ;
 
            fltmodch = new Choice() ;
            fltmodch.addItem("Ignore Drag") ;
            fltmodch.addItem("Include Drag");
            fltmodch.select(0) ;

            dmodch = new Choice() ;
            dmodch.addItem("Density") ;
            dmodch.addItem("Altitude");
            dmodch.select(1) ;

            wmodch = new Choice() ;
            wmodch.addItem("Earth Weight") ;
            wmodch.addItem("Local Weight");
            wmodch.addItem("Mass");
            wmodch.select(0) ;

            plntch = new Choice() ;
            plntch.addItem("Earth") ;
            plntch.addItem("Mars");
            plntch.select(0) ;

            untch = new Choice() ;
            untch.addItem("English Units") ;
            untch.addItem("Metric Units");
            untch.select(0) ;

            add(plntch) ;
            add(fltmodch) ;
            add(untch) ;

            add(l5) ;
            add(o5) ;
            add(l5u) ;

            add(wmodch) ;
            add(o1) ;
            add(l1u) ;
            
            add(l4) ;
            add(o4) ;
            add(l4u) ;

            add(l2) ;
            add(o2) ;
            add(l2u) ;

            add(dmodch) ;
            add(o3) ;
            add(l3u) ;
        }

        public boolean action(Event evt, Object arg) {
            if(evt.target instanceof Choice) {
               this.handleProb(arg) ;
               return true ;
            }

            else return false ;
        }
 
        public void handleProb(Object obj) {

            lunits  = untch.getSelectedIndex() ;
            planet  = plntch.getSelectedIndex() ;

            wtrat = 1.0 ;
            g0 = 32.2 ;

            if (planet == 1) {
               wtrat = .3 ;
               g0 = 9.66 ;
            }
 
            dmode = dmodch.getSelectedIndex() ;
            wmode = wmodch.getSelectedIndex() ;
            fmode = fltmodch.getSelectedIndex() ;
 
            if (lunits == 0) {  // English units labels
                if (wmode == 0) {
                   o1.setText(String.valueOf(filter3(weight))) ;
                   l1u.setText(" lbs ") ;
                }
                if (wmode == 1) {
                   o1.setText(String.valueOf(filter3(wtrat * weight))) ;
                   l1u.setText(" lbs ") ;
                }
                if (wmode == 2) {
                   o1.setText(String.valueOf(filter3(weight/32.2))) ;
                   l1u.setText(" slugs ") ;
                }
                if (dmode == 0) {
                   if (planet == 0) o3.setText(String.valueOf(filter5(rho))) ;
                   if (planet == 1) o3.setText(String.valueOf(filter7(rho))) ;
                   l3u.setText("slug/cu ft  ") ;
                }
                if (dmode == 1) {
                   o3.setText(String.valueOf(filter0(alt))) ;
                   l3u.setText(" ft  ") ;
                } 
                o4.setText(String.valueOf(filter3(area * 144.))) ;
                l4u.setText(" sq in ") ;
                o5.setText(String.valueOf(filter3(v0))) ;
                l5u.setText(" ft/sec ") ;
                if (fmode == 0) {
                   dn.out1.setText("Not Needed") ;
                   dn.lout1u.setText(" ") ;
                   dn.out2.setText(String.valueOf(filter3(ymax))) ;
                   dn.lout2u.setText(" ft ") ;
                }
                if (fmode == 1) {
                   dn.out1.setText(String.valueOf(filter3(termv))) ;
                   dn.lout1u.setText(" ft/sec ") ;
                   dn.out2.setText(String.valueOf(filter3(ymax))) ;
                   dn.lout2u.setText(" ft ") ;
                }
            }
            if (lunits == 1) {  // Metric units labels
                if (wmode == 0) {
                   o1.setText(String.valueOf(filter3(weight * 4.448))) ;
                   l1u.setText(" N ") ;
                }
                if (wmode == 1) {
                   o1.setText(String.valueOf(filter3(wtrat * weight * 4.448))) ;
                   l1u.setText(" N ") ;
                }
                if (wmode == 2) {
                   o1.setText(String.valueOf(filter3(weight * .4536))) ;
                   l1u.setText(" kg ") ;
                }
                if (dmode == 0) {
                   if (planet == 0) o3.setText(String.valueOf(filter3(rho * 515.4))) ;
                   if (planet == 1) o3.setText(String.valueOf(filter5(rho * 515.4))) ;
                   l3u.setText("kg/cu m ") ;
                }
                if (dmode == 1){
                   o3.setText(String.valueOf(filter0(alt * .3048))) ;
                   l3u.setText(" m ") ;
                } 
                o4.setText(String.valueOf(filter3(area * .3048 * .3048))) ;
                l4u.setText(" sq m ") ;
                o5.setText(String.valueOf(filter3(v0 * .3048))) ;
                l5u.setText(" m/sec ") ;
                if (fmode == 0) {
                   dn.out1.setText("Not Needed") ;
                   dn.lout1u.setText(" ") ;
                   dn.out2.setText(String.valueOf(filter3(ymax * .3048))) ;
                   dn.lout2u.setText(" m ") ;
                }
                if (fmode == 1) {
                   dn.out1.setText(String.valueOf(filter3(termv * .3048))) ;
                   dn.lout1u.setText(" m/sec ") ;
                   dn.out2.setText(String.valueOf(filter3(ymax * .3048))) ;
                   dn.lout2u.setText(" m ") ;
                }
            }
 
            computeFlt() ;
        }
     }

     class Dn extends Panel {
        Fltcalc outerparent ;
        TextField out1,out2,out3 ;
        Label lb,lout1,lout2, lout3, lout1u, lout2u, lout3u;
        Button compb ;

        Dn (Fltcalc target) {
            outerparent = target ;
            setLayout(new GridLayout(5,3,5,5)) ;
    
            lb = new Label(" Press Compute Button ", Label.CENTER) ;
            lb.setForeground(Color.red) ;

            lout1 = new Label(" Terminal Velocity ", Label.RIGHT) ;
            lout1u = new Label(" ft/sec ", Label.LEFT) ;

            lout2 = new Label(" Max Height", Label.RIGHT) ;
            lout2u = new Label(" ft ", Label.LEFT) ;

            lout3 = new Label("Time to Max Height ", Label.RIGHT) ;
            lout3u = new Label(" sec ", Label.LEFT) ;

            out1 = new TextField() ;
            out1.setBackground(Color.black) ;
            out1.setForeground(Color.yellow) ;
            out2 = new TextField() ;
            out2.setBackground(Color.black) ;
            out2.setForeground(Color.yellow) ;
            out3 = new TextField() ;
            out3.setBackground(Color.black) ;
            out3.setForeground(Color.yellow) ;

            compb = new Button("Compute") ;
            compb.setBackground(Color.red) ;
            compb.setForeground(Color.white) ;

            add(new Label(" ", Label.RIGHT)) ;
            add(lb) ;
            add(new Label(" ", Label.RIGHT)) ;

            add(new Label(" ", Label.RIGHT)) ;
            add(compb) ;
            add(new Label(" ", Label.RIGHT)) ;

            add(lout1) ;
            add(out1) ;
            add(lout1u) ;

            add(lout2) ;
            add(out2) ;
            add(lout2u) ;

            add(lout3) ;
            add(out3) ;
            add(lout3u) ;
        }
        
        public boolean action(Event evt, Object arg) {
            
            if(evt.target instanceof Button) {
               this.handleText(evt) ;
               return true ;
            }

            if(evt.target instanceof Choice) {
               this.handleText(evt) ;
               return true ;
            }

            else return false ;
        }
 
        public void handleText(Event evt) {
            Double V1,V2,V3,V4,V5 ;
            double v1,v2,v3,v4,v5 ;
            double vmax,vmin ;

            V1 = Double.valueOf(up.o1.getText()) ;
            v1 = V1.doubleValue() ;
            V2 = Double.valueOf(up.o2.getText()) ;
            v2 = V2.doubleValue() ;
            V3 = Double.valueOf(up.o3.getText()) ;
            v3 = V3.doubleValue() ;
            V4 = Double.valueOf(up.o4.getText()) ;
            v4 = V4.doubleValue() ;
            V5 = Double.valueOf(up.o5.getText()) ;
            v5 = V5.doubleValue() ;
              
            if (lunits == 0) {
               if (wmode == 0) {
                  vmax = 10000. ; 
                  vmin = .01 ;      

                  if (v1 < vmin) {
                     v1 = vmin ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  if (v1 > vmax) {
                     v1 = vmax ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  weight = v1 ;
               }
               if (wmode == 1) {
                  vmax = 10000. * wtrat ; 
                  vmin = .01 * wtrat ;      

                  if (v1 < vmin) {
                     v1 = vmin ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  if (v1 > vmax) {
                     v1 = vmax ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  weight = v1 / wtrat ;
               }
               if (wmode == 2) {
                  vmax = 10000. / 32.2 ; 
                  vmin = .01 / 32.2  ;      

                  if (v1 < vmin) {
                     v1 = vmin ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  if (v1 > vmax) {
                     v1 = vmax ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  weight = v1 * 32.2 ;
               }
            }
            if (lunits == 1) {
               if (wmode == 0) {
                  vmax = 10000. * 4.448 ; 
                  vmin = .01 * 4.448 ;      

                  if (v1 < vmin) {
                     v1 = vmin ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  if (v1 > vmax) {
                     v1 = vmax ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  weight = v1 / 4.448 ;
               }
               if (wmode == 1) {
                  vmax = 10000. * 4.448 * wtrat ; 
                  vmin = .01 * 4.448 * wtrat ;      

                  if (v1 < vmin) {
                     v1 = vmin ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  if (v1 > vmax) {
                     v1 = vmax ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  weight = v1 / 4.448 / wtrat ;
               }
               if (wmode == 2) {
                  vmax = 10000. * .4536 ; 
                  vmin = .01 * .4536 ;      

                  if (v1 < vmin) {
                     v1 = vmin ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  if (v1 > vmax) {
                     v1 = vmax ;
                     up.o1.setText(String.valueOf(filter3(v1))) ;
                  }
                  weight = v1 / .4536 ;
               }
            }

            vmax = 5. ; 
            vmin = .01 ;      

            if (v2 < vmin) {
               v2 = vmin ;
               up.o2.setText(String.valueOf(filter3(v2))) ;
            }
            if (v2 > vmax) {
               v2 = vmax ;
               up.o2.setText(String.valueOf(filter3(v2))) ;
            }
            cd = v2 ;

            if (lunits == 0) {
               if (dmode == 0) {
                  vmax = .005 ; 
                  vmin = .000001 ;      

                  if (v3 < vmin) {
                     v3 = vmin ;
                     up.o3.setText(String.valueOf(filter5(v3))) ;
                  }
                  if (v3 > vmax) {
                     v3 = vmax ;
                     up.o3.setText(String.valueOf(filter5(v3))) ;
                  }
                  rho =  v3 ;
               }

               if (dmode == 1) {
                  vmax = 100000. ; 
                  vmin = 0.0 ;      

                  if (v3 < vmin) {
                     v3 = vmin ;
                     up.o3.setText(String.valueOf(filter0(v3))) ;
                  }
                  if (v3 > vmax) {
                     v3 = vmax ;
                     up.o3.setText(String.valueOf(filter0(v3))) ;
                  }
                  alt =  v3 ;
                  getFreeStream() ;
               }
           }

           if (lunits == 1) {
               if (dmode == 0) {
                  vmax = .005 * 515.4 ; 
                  vmin = .0000001 * 515.4 ;      
   
                  if (v3 < vmin) {
                     v3 = vmin ;
                     up.o3.setText(String.valueOf(filter3(v3))) ;
                  }
                  if (v3 > vmax) {
                     v3 = vmax ;
                     up.o3.setText(String.valueOf(filter3(v3))) ;
                  }
                  rho =  v3 / 515.4 ;
               }
                
               if (dmode == 1) {
                  vmax = 100000. * .3048 ; 
                  vmin = 0.0 ;      

                  if (v3 < vmin) {
                     v3 = vmin ;
                     up.o3.setText(String.valueOf(filter0(v3))) ;
                  }
                  if (v3 > vmax) {
                     v3 = vmax ;
                     up.o3.setText(String.valueOf(filter0(v3))) ;
                  }
                  alt =  v3 / .3048 ;
                  getFreeStream() ;
               }
            }
                
            if (lunits == 0) {
                vmax = 500. * 144.; 
                vmin = 0.01 ;      

                if (v4 < vmin) {
                   v4 = vmin ;
                   up.o4.setText(String.valueOf(filter3(v4))) ;
                }
                if (v4 > vmax) {
                   v4 = vmax ;
                   up.o4.setText(String.valueOf(filter3(v4))) ;
                }
                area = v4 / 144. ;
            }
            if (lunits == 1) {
                vmax = 500. * .3048 * .3048;
                vmin = 0.01 * .3048 * .3048 ;      

                if (v4 < vmin) {
                   v4 = vmin ;
                   up.o4.setText(String.valueOf(filter3(v4))) ;
                }
                if (v4 > vmax) {
                   v4 = vmax ;
                   up.o4.setText(String.valueOf(filter3(v4))) ;
                }
               
                area = v4 / .3048 / .3048 ;
            }

            if (lunits == 0) {
                vmax = 5000.; 
                vmin = 0.01 ;      

                if (v5 < vmin) {
                   v5 = vmin ;
                   up.o5.setText(String.valueOf(filter3(v5))) ;
                }
                if (v5 > vmax) {
                   v5 = vmax ;
                   up.o5.setText(String.valueOf(filter3(v5))) ;
                }
                v0 = v5 ;
            }
            if (lunits == 1) {
                vmax = 5000. * .3048 ;
                vmin = 0.01 * .3048 ;      

                if (v5 < vmin) {
                   v5 = vmin ;
                   up.o5.setText(String.valueOf(filter3(v5))) ;
                }
                if (v5 > vmax) {
                   v5 = vmax ;
                   up.o5.setText(String.valueOf(filter3(v5))) ;
                }
               
                v0 = v5 / .3048 ;
            }

            computeFlt() ;
        }
     }
  }
}
