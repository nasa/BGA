/*
                           A Java Applet
                    to put out text for applets

                     Version 1.0  - 30 Sep 00

                         Written by Tom Benson
                       NASA Glenn Research Center

>                              NOTICE
>This software is in the Public Domain.  It may be freely copied and used in
>non-commercial products, assuming proper credit to the author is given.  IT
>MAY NOT BE RESOLD.  If you want to use the software for commercial
>products, contact the author.
>No copyright is claimed in the United States under Title 17, U. S. Code.
>This software is provided "as is" without any warranty of any kind, either
>express, implied, or statutory, including, but not limited to, any warranty
>that the software will conform to specifications, any implied warranties of
>merchantability, fitness for a particular purpose, and freedom from
>infringement, and any warranty that the documentation will conform to the
>program, or any warranty that the software will be error free.
>In no event shall NASA be liable for any damages, including, but not
>limited to direct, indirect, special or consequential damages, arising out
>of, resulting from, or in any way connected with this software, whether or
>not based on warranty, contract, tort or otherwise, whether or not injury
>was sustained by persons or property or otherwise, and whether or not loss
>was sustained from, or arose out of the results of, or use of, the software
>or services provided hereunder.

*/

import java.awt.*;

public class Reader extends java.applet.Applet {
 
   TextArea prnt ;
 
   public void init() {

     setLayout(new GridLayout(1,1,0,0)) ;
 
     prnt = new TextArea() ;
     prnt.setEditable(false) ;

     add(prnt) ;
     loadPrint() ;
   }
 
   public void loadPrint() {
     String str ;

     str =   
       " \n Use the scroll bar at the right to move the text \n" +
       " in this box. \n\n " ;
     prnt.append(str) ;

     str =   
       " On the left view window we see a symmetric airfoil. \n" +
       " The distance over the top is equal to the distance underneath. \n" + 
       " The flow around the airfoil is shown by moving particles \n" +
       " (lines colored blue and white). The left end of each little  \n" +
       " line is the location of the particle, and the line is \n" +
       " inclined at the local direction of the flow. \n" +
       " The streamwise distance between the particles is proportional to \n" +
       " the local velocity. \n" +
       " Particles are constantly being released upstream (to the left) \n" +
       " at a constant distance from the airfoil. You can change the \n" +
       " angle of the airfoil by using the slider or the type-in box \n" +
       " directly below the window. \n\n " ;
     prnt.append(str) ;

     str =   
       " On the right side of the simulator is a gage with some buttons \n" +
       "  and some sliders. The gage tells you the value of the velocity\n" +
       "  or pressure at the location of the probe (little purple dot)\n" +
       "  in the left view window. You can change the location from side\n" + 
       "  to side by using the slider located below the gage, and you\n" +
       "  can change the location up and down by using the slider\n" +
       "  to the left of the gage. You select which variable to display \n" + 
       "  by using the white buttons labeled Velocity, Pressure,\n" +
       "  or Smoke. Smoke causes green particles to be released from the probe. \n" +
       "  The blue buttons control the type of display shown in the left \n" +
       "  view window. \n" ;
     prnt.append(str) ;

     str =   
       " \n\n  Experiment #1 \n\n " ;
     prnt.append(str) ;

     str =   
        " If you have been moving the airfoil, set the angle to 0.0 degrees \n" +
        " and push the white button labeled Velocity, and the blue buttons\n" +
        " labeled Animation and Close View.\n" +
        " Now move the probe as far to the left as possible and note the \n" +
        " velocity upstream.\n" +
        " Move the probe as close to the lower airfoil surface as you can\n" +
        " near the thickest part of the airfoil. \n " +
        " What is the velocity at that location? \n" +
        " Move the probe to the upper surface.\n" +
        " What is the velocity at that location? \n" +
        " How does it compare to the upstream value?\n" +
        " Note that the airfoil is generating no lift. Now change the angle of\n" +
        " the airfoil to some positive value using the slider below the \n" +
        " view window.\n" +
        " What is the value of the lift?  \n" +
        " Use the probe to again determine the velocity on the upper\n" +
        " and lower surface of the foil. \n" +
        " Which surface has the higher velocity?\n" +
        " Now push the white button labeled Pressure.\n" +
        " Using the probe, which surface has the highest pressure? \n" +
        " How does this relate to the velocity?\n" ;

     prnt.append(str) ;

     str =   
       " \n\n  Experiment #2 \n\n " ;
     prnt.append(str) ;

     str =   
        " Set the angle to a large positive value and push the \n" +
        " blue button labeled Direction. This freezes the flow field and \n" +
        " lets you see three groups of particles colored yellow, white,  \n" +
        " and blue. Each group of particles were released at the same time \n" +
        " at the same distance from the airfoil. \n" +
        " You can change this distance by using the slider at the \n" +
        " lower left (Rake release point). Use the slider to move the yellow \n" +
        " particle nearest the top surface of the airfoil to the rear of \n" +
        " the airfoil.  \n" +
        " Where is the yellow particle nearest the bottom surface of the airfoil? \n" +
        " Do the particles meet at the trailing edge? \n" +
        " Push the blue button labeled Far View. \n" +
        " Do the particles line up far downstream from the airfoil? \n" +
        " Change the angle of the airfoil to some large \n" +
        " negative number.  \n" +
        " What happens to the relative location of the particles? \n" ;

     prnt.append(str) ;

     str =   
       " \n Use the scroll bar at the right to move the text \n" +
       " in this box. \n\n " ;
     prnt.append(str) ;

   }
}
