/*  
                      Normal Shock Calculator
                     Interactive Program to solve 
                    Standard Atmosphere Equations
                    and Normal shock relations 

                          A Java Applet

                     Version 1.1a   - 31 May 06

                         Written by Tom Benson
                       NASA Glenn Research Center

>                              NOTICE
>This software is in the Public Domain.  It may be freely copied and used in
>non-commercial products, assuming proper credit to the author is given.  IT
>MAY NOT BE RESOLD.  If you want to use the software for commercial
>products, contact the author.
>No copyright is claimed in the United States under Title 17, U. S. Code.
>This software is provided "as is" without any warranty of any kind, either
>express, implied, or statutory, including, but not limited to, any warranty
>that the software will conform to specifications, any implied warranties of
>merchantability, fitness for a particular purpose, and freedom from
>infringement, and any warranty that the documentation will conform to the
>program, or any warranty that the software will be error free.
>In no event shall NASA be liable for any damages, including, but not
>limited to direct, indirect, special or consequential damages, arising out
>of, resulting from, or in any way connected with this software, whether or
>not based on warranty, contract, tort or otherwise, whether or not injury
>was sustained by persons or property or otherwise, and whether or not loss
>was sustained from, or arose out of the results of, or use of, the software
>or services provided hereunder.

      New Test :
                 *  use input panel from Mach calculator
                   add calculation routine from Shock simulator
                   add special output panel 

                                                     TJB 31 May 06

*/

import java.awt.*;
import java.lang.Math ;

public class Normal extends java.applet.Applet {

   double gama,alt, rgas, a0, q0, vel ;
   double ps0, pt0, rho0, ts0, mach ;
   double prat, ptrat, rhorat, trat, mrat ;
   double ps1, pt1, rho1, ts1, mach1;
   int lunits, planet ;
   int mode ;

   In in ;

   public void init() {

     setLayout(new GridLayout(1,1,0,0)) ;

     setDefaults () ;

     in = new In(this) ;

     add(in) ;

     computeNormal() ;
  }
 
  public Insets insets() {
     return new Insets(10,10,10,10) ;
  }

  public void setDefaults() {
     lunits = 0;
     mode = 0 ;
     planet = 0 ;

     alt = 0.0 ;
     mach = 2. ;
     gama = 1.4 ;
  }

  public void computeNormal() {
     double gm1,gp1,msq,m1sq ;

  // get free stream conditions

     if (planet == 0) {    // Earth  standard day
        rgas = 1718. ;                /* ft2/sec2 R */

        if (alt <= 36152.) {           // Troposphere
          ts0 = 518.6 - 3.56 * alt/1000. ;
          ps0 = 2116. * Math.pow(ts0/518.688,5.256) ;
        }
        if (alt >= 36152. && alt <= 82345.) {   // Stratosphere
          ts0 = 389.98 ;
          ps0 = 2116. * .2236 *
                 Math.exp((36152.-alt)/(53.35*389.98)) ;
        }
        if (alt >= 82345. && alt <= 155348.) {          
          ts0 = 389.98 + 1.645 * (alt-82345.)/1000. ;
          ps0 = 2116. *.02456 * Math.pow(ts0/389.98,-11.388) ;
        }
        if (alt >= 155348. && alt <= 175346.) {          
          ts0 = 508.788 ;
          ps0 = 2116. * .00118866 *
                 Math.exp((155348.-alt)/(53.35*508.788)) ;
        }
        if (alt >= 175346. && alt <= 262448.) {          
          ts0 = 508.788 - 2.46888 * (alt-175346.)/1000. ;
          ps0 = 2116. *.00057596 * Math.pow(ts0/508.788,7.59216) ;
        }
     }

     if (planet == 1) {   // Mars - curve fit of orbiter data
        rgas = 1149. ;                /* ft2/sec2 R */

        if (alt <= 22960.) {
          ts0 = 434.02 - .548 * alt/1000. ;
          ps0 = 14.62 * Math.pow(2.71828,-.00003 * alt) ;
        }
        if (alt > 22960.) {
          ts0 = 449.36 - 1.217 * alt/1000. ;
          ps0 = 14.62 * Math.pow(2.71828,-.00003 * alt) ;
        }
     }

     gm1 = gama - 1.0 ;
     gp1 = gama + 1.0 ;

     rho0 = ps0 / rgas / ts0 ;
     a0 = Math.sqrt(gama*rgas*ts0) ;  // feet /sec
     a0 = a0 * 60.0 / 88. ;   // mph
                       // compute either mach or velocity 
     msq = mach * mach ;

     q0 = gama / 2.0 * msq * ps0 ;
     pt0 = ps0 * Math.pow((1.0 + .5 * gm1 * msq), (gama/gm1)) ;

     prat   = (2.0*gama*msq - gm1)/gp1 ;
     rhorat = (gp1*msq)/(gm1*msq + 2.0) ;
     trat   = prat / rhorat ;
     ptrat  = (Math.pow(rhorat,(gama/gm1)))
               * (Math.pow((1.0/prat),(1.0/gm1))) ;
     m1sq   = msq / (prat * rhorat) ;
     mach1  = Math.sqrt(m1sq) ;

     ps1 = prat * ps0 ;
     pt1 = ptrat * pt0 ;
     ts1 = trat * ts0 ;
     rho1 = rhorat * rho0 ;
     mrat = mach1 / mach ;

     if (lunits == 0) {
        in.dn.o1.setText(String.valueOf(filter3(ps0))) ;
        in.dn.o2.setText(String.valueOf(filter3(prat))) ;
        in.dn.o3.setText(String.valueOf(filter3(ps1))) ;
        in.dn.o4.setText(String.valueOf(filter3(pt0))) ;
        in.dn.o5.setText(String.valueOf(filter5(ptrat))) ;
        in.dn.o6.setText(String.valueOf(filter3(pt1))) ;
        in.dn.o7.setText(String.valueOf(filter0(ts0))) ;
        in.dn.o8.setText(String.valueOf(filter3(trat))) ;
        in.dn.o9.setText(String.valueOf(filter0(ts1))) ;
        in.dn.o10.setText(String.valueOf(filter9(rho0))) ;
        in.dn.o11.setText(String.valueOf(filter3(rhorat))) ;
        in.dn.o12.setText(String.valueOf(filter9(rho1))) ;
        in.dn.o13.setText(String.valueOf(filter5(mach))) ;
        in.dn.o14.setText(String.valueOf(filter3(mrat))) ;
        in.dn.o15.setText(String.valueOf(filter5(mach1))) ;
     }
     if (lunits == 1) {
        in.dn.o1.setText(String.valueOf(filter5(ps0* 4.448/.3048/.3048/1000.))) ;
        in.dn.o2.setText(String.valueOf(filter3(prat))) ;
        in.dn.o3.setText(String.valueOf(filter5(ps1* 4.448/.3048/.3048/1000.))) ;
        in.dn.o4.setText(String.valueOf(filter5(pt0* 4.448/.3048/.3048/1000.))) ;
        in.dn.o5.setText(String.valueOf(filter5(ptrat))) ;
        in.dn.o6.setText(String.valueOf(filter5(pt1* 4.448/.3048/.3048/1000.))) ;
        in.dn.o7.setText(String.valueOf(filter0(ts0 * .55555))) ;
        in.dn.o8.setText(String.valueOf(filter3(trat))) ;
        in.dn.o9.setText(String.valueOf(filter0(ts1 * .55555))) ;
        in.dn.o10.setText(String.valueOf(filter9(rho0 * 515.4))) ;
        in.dn.o11.setText(String.valueOf(filter3(rhorat))) ;
        in.dn.o12.setText(String.valueOf(filter9(rho1 * 515.4))) ;
        in.dn.o13.setText(String.valueOf(filter5(mach))) ;
        in.dn.o14.setText(String.valueOf(filter3(mrat))) ;
        in.dn.o15.setText(String.valueOf(filter5(mach1))) ;
     }
 
     if (mode == 0) loadInpt() ;
  }
 
  public void loadInpt() {
     if (lunits == 0) {
         in.up.o1.setText(String.valueOf(filter0(alt))) ;
         in.up.o2.setText(String.valueOf(filter3(mach))) ;
         in.up.o3.setText(String.valueOf(filter3(gama))) ;
     }
     if (lunits == 1) {
         in.up.o1.setText(String.valueOf(filter0(alt*.3048))) ;
         in.up.o2.setText(String.valueOf(filter3(mach))) ;
         in.up.o3.setText(String.valueOf(filter3(gama))) ;
     }
  }

  public int filter0(double inumbr) {
     //  integer output
       float number ;
       int intermed ;

       intermed = (int) (inumbr) ;
       number = (float) (intermed);
       return intermed ;
  }
 
  public float filter3(double inumbr) {
     //  output only to .001
       float number ;
       int intermed ;
  
       intermed = (int) (inumbr * 1000.) ;
       number = (float) (intermed / 1000. );
       return number ;
  }

  public float filter5(double inumbr) {
     //  output only to .00001
       float number ;
       int intermed ;
  
       intermed = (int) (inumbr * 100000.) ;
       number = (float) (intermed / 100000. );
       return number ;
  }

  public float filter9(double inumbr) {
     //  output only to .000000001
       float number ;
       int intermed ;
 
       intermed = (int) (inumbr * 1000000000.) ;
       number = (float) (intermed / 1000000000. );
       return number ;
  }

  class In extends Panel {
     Normal outerparent ;
     Titl titl ;
     Up up ;
     Dn dn ;

     In (Normal target) {                           
        outerparent = target ;
        setLayout(new GridLayout(3,1,5,5)) ;

        titl = new Titl(outerparent) ;
        up = new Up(outerparent) ;
        dn = new Dn(outerparent) ;

        add(titl) ;
        add(up) ;
        add(dn) ;
     }

     public Insets insets() {
        return new Insets(5,5,0,0) ;
     }

     class Titl extends Panel {
        Label la ;
        In2 in2;

        Titl (Normal target) {                           
            outerparent = target ;
            setLayout(new GridLayout(2,1,0,0)) ;

            la = new Label("Normal Shock Calculator", Label.CENTER) ;
            la.setForeground(Color.red) ;

            in2 = new In2(outerparent) ;
 
            add(la) ;
            add(in2) ;
        }
 
        class In2 extends Panel {
           Label lc,lb ;
           Choice plntch,untch ;

           In2 (Normal target) {                           
               outerparent = target ;
               setLayout(new GridLayout(2,4,0,0)) ;

               lb = new Label("Units:", Label.RIGHT) ;
               lb.setForeground(Color.red) ;
 
               lc = new Label("Planet:", Label.RIGHT) ;
               lc.setForeground(Color.red) ;
 
               plntch = new Choice() ;
               plntch.addItem("Earth") ;
               plntch.addItem("Mars");
               plntch.setBackground(Color.white) ;
               plntch.setForeground(Color.red) ;
               plntch.select(0) ;

               untch = new Choice() ;
               untch.addItem("Imperial") ;
               untch.addItem("Metric");
               untch.setBackground(Color.white) ;
               untch.setForeground(Color.red) ;
               untch.select(0) ;

               add(new Label(" ", Label.RIGHT)) ;
               add(lb) ;
               add(untch) ;
               add(new Label(" ", Label.RIGHT)) ;

               add(new Label(" ", Label.RIGHT)) ;
               add(lc) ;
               add(plntch) ;
               add(new Label(" ", Label.RIGHT)) ;
           }

           public boolean handleEvent(Event evt) {
               if(evt.id == Event.ACTION_EVENT) {
                  planet  = plntch.getSelectedIndex() ;
                  lunits  = untch.getSelectedIndex() ;

                  if (planet == 0) {  // Earth
                     gama = 1.4 ;
                     up.o3.setText(String.valueOf(filter3(gama))) ;
                  }
                  if (planet == 1) {  // Mars
                     gama = 1.29 ;
                     up.o3.setText(String.valueOf(filter3(gama))) ;
                  }

                  if (lunits == 0) {  // English units labels
                      up.l1u.setText("feet") ;
                      dn.l1.setText("Static Pressure-psf") ;
                      dn.l2.setText("Total Pressure-psf") ;
                      dn.l3.setText("Static Temperature-R") ;
                      dn.l4.setText("Density-slug/cu ft") ;
                  }
                  if (lunits == 1) {  // Metric units labels
                      up.l1u.setText("meters") ;
                      dn.l1.setText("Static Pressure-kPa") ;
                      dn.l2.setText("Total Pressure-kPa") ;
                      dn.l3.setText("Static Temperature-K") ;
                      dn.l4.setText("Density-kg/cu m") ;
                  }
 
                  mode = 0 ;
                  computeNormal() ;
                  return true ;
               }
               else return false ;
           }
        }
     }

     class Up extends Panel {
        TextField o1,o2,o3 ;
        Label l1,l1u,l2u, la ;
        Button bt1;

        Up (Normal target) {                           
            outerparent = target ;
            setLayout(new GridLayout(4,4,5,5)) ;
    
            la = new Label("Input", Label.LEFT) ;
            la.setForeground(Color.red) ;

            l1 = new Label("Altitude", Label.RIGHT) ;
            l1u = new Label(" feet ", Label.LEFT) ;
   
            o1 = new TextField() ;
            o1.setBackground(Color.white) ;
            o1.setForeground(Color.black) ;

            o2 = new TextField() ;
            o2.setBackground(Color.white) ;
            o2.setForeground(Color.black) ;
 
            o3 = new TextField() ;
            o3.setBackground(Color.white) ;
            o3.setForeground(Color.black) ;
 
            bt1 = new Button("COMPUTE") ;
            bt1.setBackground(Color.red) ;
            bt1.setForeground(Color.white) ;

            add(la) ;
            add(new Label("Mach ", Label.RIGHT)) ;
            add(o2) ;
            add(new Label(" ", Label.RIGHT)) ;

            add(new Label(" ", Label.RIGHT)) ;
            add(new Label("Gamma ", Label.RIGHT)) ;
            add(o3) ;
            add(new Label(" ", Label.RIGHT)) ;

            add(new Label(" ", Label.RIGHT)) ;
            add(l1) ;
            add(o1) ;
            add(l1u) ;

            add(new Label(" ", Label.RIGHT)) ;
            add(new Label("Press -> ", Label.RIGHT)) ;
            add(bt1) ;
            add(new Label(" ", Label.RIGHT)) ;
        }

        public Insets insets() {
           return new Insets(5,5,5,5) ;
        }

        public boolean action(Event evt, Object arg) {
            if(evt.target instanceof Button) {
               this.handleBut(evt) ;
               return true ;
            }

            else return false ;
        }
 
        public void handleBut(Event evt) {
            Double V1,V2,V3 ;
            double v1,v2,v3 ;

            V1 = Double.valueOf(o1.getText()) ;
            v1 = V1.doubleValue() ;
            V2 = Double.valueOf(o2.getText()) ;
            v2 = V2.doubleValue() ;
            V3 = Double.valueOf(o3.getText()) ;
            v3 = V3.doubleValue() ;

            if (lunits == 0) {
                if (v1 < 0.0) {
                   v1 = 0.0 ;
                   o1.setText(String.valueOf(filter0(v1))) ;
                }
                if (v1 >250000.0) {
                   v1 = 250000.0 ;
                   o1.setText(String.valueOf(filter0(v1))) ;
                }
                alt = v1 ;
            }
            if (lunits == 1) {
                if (v1 < 0.0) {
                   v1 = 0.0 ;
                   o1.setText(String.valueOf(filter0(v1))) ;
                }
                if (v1 >76200.0) {
                   v1 = 76200.0 ;
                   o1.setText(String.valueOf(filter0(v1))) ;
                }
                alt = v1 / .3048 ;
            }

            if (v2 < 1.0) {
                v2 = 1.0 ;
                o2.setText(String.valueOf(filter0(v2))) ;
            }
            if (v2 >25.0) {
                v2 = 25.0 ;
                o2.setText(String.valueOf(filter0(v2))) ;
            }
            mach = v2 ;

            if (v3 < 1.0) {
                v3 = 1.0 ;
                o3.setText(String.valueOf(filter0(v3))) ;
            }
            if (v3 > 2.0) {
                v3 = 2.0 ;
                o3.setText(String.valueOf(filter0(v3))) ;
            }
            gama = v3 ;

            mode = 1;
            computeNormal() ;
        }
     }

     class Dn extends Panel {
        Normal outerparent ;
        TextField o1,o2,o3,o4,o5,o6,o7,o8,o9,o10 ;
        TextField o11,o12,o13,o14,o15 ;
        Label l1,l2,l3,l4,l5 ;
        Label lb ;

        Dn (Normal target) {
            outerparent = target ;
            setLayout(new GridLayout(6,4,0,0)) ;
    
            lb = new Label("Output", Label.LEFT) ;
            lb.setForeground(Color.blue) ;

            l1 = new Label("Static Pressure-psf", Label.CENTER) ;
            l2 = new Label("Total Pressure-psf", Label.CENTER) ;
            l3 = new Label("Static Temperature-R", Label.CENTER) ;
            l4 = new Label("Density-slug/cu ft", Label.CENTER) ;
            l5 = new Label("Mach", Label.CENTER) ;
   
            o1 = new TextField() ;
            o1.setBackground(Color.black) ;
            o1.setForeground(Color.yellow) ;
            o2 = new TextField() ;
            o2.setBackground(Color.black) ;
            o2.setForeground(Color.yellow) ;
            o3 = new TextField() ;
            o3.setBackground(Color.black) ;
            o3.setForeground(Color.yellow) ;
            o4 = new TextField() ;
            o4.setBackground(Color.black) ;
            o4.setForeground(Color.yellow) ;
            o5 = new TextField() ;
            o5.setBackground(Color.black) ;
            o5.setForeground(Color.yellow) ;
            o6 = new TextField() ;
            o6.setBackground(Color.black) ;
            o6.setForeground(Color.yellow) ;
            o7 = new TextField() ;
            o7.setBackground(Color.black) ;
            o7.setForeground(Color.yellow) ;
            o8 = new TextField() ;
            o8.setBackground(Color.black) ;
            o8.setForeground(Color.yellow) ;
            o9 = new TextField() ;
            o9.setBackground(Color.black) ;
            o9.setForeground(Color.yellow) ;
            o10 = new TextField() ;
            o10.setBackground(Color.black) ;
            o10.setForeground(Color.yellow) ;
            o11 = new TextField() ;
            o11.setBackground(Color.black) ;
            o11.setForeground(Color.yellow) ;
            o12 = new TextField() ;
            o12.setBackground(Color.black) ;
            o12.setForeground(Color.yellow) ;
            o13 = new TextField() ;
            o13.setBackground(Color.black) ;
            o13.setForeground(Color.yellow) ;
            o14 = new TextField() ;
            o14.setBackground(Color.black) ;
            o14.setForeground(Color.yellow) ;
            o15 = new TextField() ;
            o15.setBackground(Color.black) ;
            o15.setForeground(Color.yellow) ;

            add(lb) ;
            add(new Label("Upstream ", Label.CENTER)) ;
            add(new Label("Ratio ", Label.CENTER)) ;
            add(new Label("Downstream ", Label.CENTER)) ;

            add(l1) ;
            add(o1) ;
            add(o2) ;
            add(o3) ;

            add(l2) ;
            add(o4) ;
            add(o5) ;
            add(o6) ;

            add(l3) ;
            add(o7) ;
            add(o8) ;
            add(o9) ;

            add(l4) ;
            add(o10) ;
            add(o11) ;
            add(o12) ;

            add(l5) ;
            add(o13) ;
            add(o14) ;
            add(o15) ;

        }
     }
  }
}
