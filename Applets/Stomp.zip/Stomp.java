/*
                    Stomp - a Java viewer for the BGR
                      interactive stomp rocket launcher 

                     Version 1.0b   - 6 Jun 05

                         Written by Tom Benson
                       NASA Glenn Research Center

>                              NOTICE
>This software is in the Public Domain.  It may be freely copied and used in
>non-commercial products, assuming proper credit to the author is given.  IT
>MAY NOT BE RESOLD.  If you want to use the software for commercial
>products, contact the author.
>No copyright is claimed in the United States under Title 17, U. S. Code.
>This software is provided "as is" without any warranty of any kind, either
>express, implied, or statutory, including, but not limited to, any warranty
>that the software will conform to specifications, any implied warranties of
>merchantability, fitness for a particular purpose, and freedom from
>infringement, and any warranty that the documentation will conform to the
>program, or any warranty that the software will be error free.
>In no event shall NASA be liable for any damages, including, but not
>limited to direct, indirect, special or consequential damages, arising out
>of, resulting from, or in any way connected with this software, whether or
>not based on warranty, contract, tort or otherwise, whether or not injury
>was sustained by persons or property or otherwise, and whether or not loss
>was sustained from, or arose out of the results of, or use of, the software
>or services provided hereunder.

*/

import java.awt.*;
import java.lang.Math ;

public class Stomp extends java.applet.Applet {
 
   int counter,inc,anim,dir ;

   Dispnl dispnl ;
   Image offscreenImg ;
   Graphics offsGg ;
   Image[] animg = new Image[30] ;

   public void init() {
     int i;

     for (i = 1; i <= 25; i++ ) {
       animg[i] = getImage(getCodeBase(),
               "st" + i + ".gif") ;
     }

     offscreenImg = createImage(this.size().width,
                      this.size().height) ;
     offsGg = offscreenImg.getGraphics() ;

     setLayout(new GridLayout(1,1,5,5)) ;
 
     dispnl = new Dispnl(this) ;
 
     add(dispnl) ;
 
     counter = 1 ;
     inc = 0 ;
     anim = 0;
     dir = 1 ;
     dispnl.pic.start() ;
   }
 
 
  class Dispnl extends Panel {
     Stomp outerparent ;
     Pic pic ;
     Conpnl conpnl ;

     Dispnl (Stomp target) {
        outerparent = target ;
        setLayout(new BorderLayout(5,5)) ;
 
        pic = new Pic() ;
        conpnl = new Conpnl() ;
 
        add("Center", pic) ;
        add("South", conpnl) ;
     }
 
     class Conpnl extends Panel {
        Stomp outerparent ;
        Button bleft,brset,bright ;
 
        Conpnl () {
          int i1 ;
 
          setLayout(new GridLayout(1,5,5,5)) ;

          bleft = new Button("Start") ;
          bleft.setBackground(Color.blue) ;
          bleft.setForeground(Color.white) ;

          brset = new Button("Pressurize") ;
          brset.setBackground(Color.white) ;
          brset.setForeground(Color.blue) ;

          bright = new Button("Launch") ;
          bright.setBackground(Color.red) ;
          bright.setForeground(Color.white) ;

          add(new Label(" ", Label.CENTER)) ;
          add(bleft) ;
          add(brset) ;
          add(bright) ;
          add(new Label(" ", Label.CENTER)) ;
        }
 
        public boolean action(Event evt, Object arg) {
          if(evt.target instanceof Button) {
             String label = (String)arg ;
             if(label.equals("Start")) {
                 inc = 0 ;
                 anim = 0;
                 counter = 1 ;
             }
             if(label.equals("Pressurize")) {
                 counter = 0 ;
                 inc = 1 ;
                 anim = 0;
                 dir = 1 ;
             }
             if(label.equals("Launch")) {
                 if (counter == 11) {
                    inc = 1 ;
                    dir = 2 ;
                 }
                 else inc = 0 ;
             }
             return true ;
          }
          else return false ;
        } // end Handler

     }  // end Conpnl

     class Pic extends Canvas
             implements Runnable{
        Stomp outerparent ;
        Thread runner ;
        Image displimg ;
   
        Pic () {
            setBackground(Color.white) ;
            runner = null ;
            displimg = getImage(getCodeBase(),"st1.gif") ;
        }

        public void start() {
           if (runner == null) {
              runner = new Thread(this) ;
              runner.start() ;
           }
        }
   
        public void run() {
          while (true) {
              counter = counter + inc ;
              if (anim == 10 && dir == 1) inc = 0 ;
              if (anim == 23 && dir == 2) inc = 0 ;
              anim = anim + inc ;
              displimg = animg[counter] ;
              try { Thread.sleep(100); }
              catch (InterruptedException e) {}
              pic.repaint() ;
          }
        }

        public void update(Graphics g) {
           pic.paint(g) ;
        }
   
        public void paint(Graphics g) {
    
            offsGg.drawImage(displimg,0,0,this) ;
            g.drawImage(offscreenImg,0,0,this) ;
        }
      }
   }
}
